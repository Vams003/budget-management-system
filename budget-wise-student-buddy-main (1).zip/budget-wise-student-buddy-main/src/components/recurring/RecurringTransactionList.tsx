
import React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { RecurringTransaction } from "@/types/database";
import RecurringTransactionItem from "./RecurringTransactionItem";

interface RecurringTransactionListProps {
  transactions: RecurringTransaction[] | null;
  isLoading: boolean;
  onEdit: (transaction: RecurringTransaction) => void;
  onDelete: (transaction: RecurringTransaction) => void;
}

const RecurringTransactionList = ({
  transactions,
  isLoading,
  onEdit,
  onDelete,
}: RecurringTransactionListProps) => {
  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Description</TableHead>
            <TableHead>Category</TableHead>
            <TableHead>Frequency</TableHead>
            <TableHead>Amount</TableHead>
            <TableHead>Start Date</TableHead>
            <TableHead>End Date</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {isLoading ? (
            <TableRow>
              <TableCell colSpan={7} className="text-center py-8">
                Loading recurring transactions...
              </TableCell>
            </TableRow>
          ) : !transactions || transactions.length === 0 ? (
            <TableRow>
              <TableCell colSpan={7} className="text-center py-8">
                No recurring transactions found. Create one to get started!
              </TableCell>
            </TableRow>
          ) : (
            transactions.map((transaction) => (
              <RecurringTransactionItem
                key={transaction.id}
                transaction={transaction}
                onEdit={() => onEdit(transaction)}
                onDelete={() => onDelete(transaction)}
              />
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
};

export default RecurringTransactionList;
