
import React from "react";
import { Calendar, Pencil, Trash2 } from "lucide-react";
import { RecurringTransaction } from "@/types/database";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { CurrencyDisplay } from "@/components/ui/currency-display";

interface RecurringTransactionItemProps {
  transaction: RecurringTransaction;
  onEdit: (transaction: RecurringTransaction) => void;
  onDelete: (transaction: RecurringTransaction) => void;
}

const RecurringTransactionItem = ({
  transaction,
  onEdit,
  onDelete,
}: RecurringTransactionItemProps) => {
  // Format the recurring date range
  const formatDateRange = () => {
    const startDate = new Date(transaction.start_date);
    const endDate = transaction.end_date ? new Date(transaction.end_date) : null;
    
    const formattedStart = startDate.toLocaleDateString();
    
    if (!endDate) {
      return `From ${formattedStart}`;
    }
    
    const formattedEnd = endDate.toLocaleDateString();
    return `${formattedStart} to ${formattedEnd}`;
  };

  return (
    <div className="flex flex-col md:flex-row md:items-center justify-between p-4 border rounded-lg gap-4">
      <div className="flex flex-col md:flex-row md:items-center gap-4">
        <div className={cn(
          "w-8 h-8 rounded-full flex items-center justify-center",
          transaction.is_expense ? "bg-red-100 text-red-600" : "bg-green-100 text-green-600"
        )}>
          <span className="text-lg font-bold">
            {transaction.is_expense ? "-" : "+"}
          </span>
        </div>
        
        <div>
          <h3 className="font-medium">
            {transaction.description || "Unnamed Transaction"}
          </h3>
          <div className="flex items-center text-xs text-muted-foreground mt-1">
            <span className="capitalize">{transaction.frequency}</span>
            <span className="mx-1">•</span>
            <Calendar className="h-3 w-3 mr-1" />
            <span>{formatDateRange()}</span>
          </div>
        </div>
      </div>
      
      <div className="flex items-center justify-between md:justify-end w-full md:w-auto gap-4">
        <span className={cn(
          "font-bold",
          transaction.is_expense ? "text-red-600" : "text-green-600"
        )}>
          <CurrencyDisplay amount={Number(transaction.amount)} />
        </span>
        
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="icon" 
            onClick={() => onEdit(transaction)}
          >
            <Pencil className="h-4 w-4" />
          </Button>
          <Button 
            variant="outline" 
            size="icon" 
            onClick={() => onDelete(transaction)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default RecurringTransactionItem;
