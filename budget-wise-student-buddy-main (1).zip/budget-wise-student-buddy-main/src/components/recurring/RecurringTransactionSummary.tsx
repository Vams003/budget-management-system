
import React from "react";
import { useCurrency } from "@/hooks/use-currency";
import { RecurringTransaction } from "@/types/database";
import { CurrencyDisplay } from "@/components/ui/currency-display";

interface RecurringTransactionSummaryProps {
  transactions: RecurringTransaction[] | null;
}

const RecurringTransactionSummary = ({ transactions }: RecurringTransactionSummaryProps) => {
  const { formatCurrency } = useCurrency();
  
  if (!transactions || transactions.length === 0) {
    return null;
  }

  const totalExpenses = transactions
    .filter(t => t.is_expense)
    .reduce((sum, t) => sum + Number(t.amount), 0);
  
  const totalIncome = transactions
    .filter(t => !t.is_expense)
    .reduce((sum, t) => sum + Number(t.amount), 0);
  
  const countExpenses = transactions.filter(t => t.is_expense).length;
  const countIncome = transactions.filter(t => !t.is_expense).length;

  return (
    <div className="grid grid-cols-2 gap-4 mb-6">
      <div className="p-4 border rounded-md bg-background">
        <h3 className="text-sm font-medium text-muted-foreground">Recurring Expenses</h3>
        <p className="mt-1 text-2xl font-semibold text-destructive">
          <CurrencyDisplay amount={totalExpenses} />
        </p>
        <p className="text-xs text-muted-foreground mt-1">
          {countExpenses} {countExpenses === 1 ? 'transaction' : 'transactions'}
        </p>
      </div>
      <div className="p-4 border rounded-md bg-background">
        <h3 className="text-sm font-medium text-muted-foreground">Recurring Income</h3>
        <p className="mt-1 text-2xl font-semibold text-green-600">
          <CurrencyDisplay amount={totalIncome} />
        </p>
        <p className="text-xs text-muted-foreground mt-1">
          {countIncome} {countIncome === 1 ? 'transaction' : 'transactions'}
        </p>
      </div>
    </div>
  );
};

export default RecurringTransactionSummary;
