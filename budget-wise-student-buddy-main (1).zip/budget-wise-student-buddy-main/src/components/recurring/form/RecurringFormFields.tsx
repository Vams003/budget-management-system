
import React from "react";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import CurrencyInput from "./CurrencyInput";
import CategorySelector from "./CategorySelector";
import FrequencySelector from "./FrequencySelector";
import DatePicker from "./DatePicker";
import { RecurringFormState } from "./useRecurringFormState";

type TransactionType = "expense" | "income";

interface RecurringFormFieldsProps {
  formState: RecurringFormState;
}

const RecurringFormFields = ({ formState }: RecurringFormFieldsProps) => {
  return (
    <div className="grid gap-4 py-4">
      <div className="grid gap-2">
        <Label htmlFor="transaction-type">Type</Label>
        <Select
          value={formState.isExpense ? "expense" : "income"}
          onValueChange={(value: TransactionType) => formState.setIsExpense(value === "expense")}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="expense">Expense</SelectItem>
            <SelectItem value="income">Income</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <CurrencyInput 
        value={formState.amount} 
        onChange={formState.setAmount} 
      />

      <div className="grid gap-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={formState.description}
          onChange={(e) => formState.setDescription(e.target.value)}
          placeholder="Rent, Netflix subscription, etc."
        />
      </div>

      <CategorySelector
        value={formState.categoryId || "uncategorized"}
        onChange={formState.setCategoryId}
        isExpense={formState.isExpense}
      />

      <FrequencySelector 
        value={formState.frequency} 
        onChange={formState.setFrequency}
      />

      <DatePicker
        label="Start Date"
        date={formState.startDate}
        onDateChange={formState.setStartDate}
        placeholder="Select start date"
        id="start-date"
      />

      <div className="grid gap-2">
        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            id="end-date-toggle"
            checked={formState.showEndDate}
            onChange={(e) => formState.setShowEndDate(e.target.checked)}
            className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
          />
          <Label htmlFor="end-date-toggle">Set End Date</Label>
        </div>

        {formState.showEndDate && (
          <DatePicker
            label=""
            date={formState.endDate}
            onDateChange={formState.setEndDate}
            placeholder="Select end date"
            id="end-date"
          />
        )}
      </div>
    </div>
  );
};

export default RecurringFormFields;
