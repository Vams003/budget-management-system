import React, { useState } from "react";
import { format } from 'date-fns';
import { toast } from "@/hooks/use-toast";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { Category } from "@/types/database";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import CurrencyInput from "./CurrencyInput";
import { FrequencyType } from "@/types/supabase-rpc";
import { CheckedState } from "@radix-ui/react-checkbox";

interface RecurringFormState {
  description: string;
  amount: string;
  isExpense: boolean;
  frequency: FrequencyType;
  startDate: string;
  endDate: string | null;
  categoryId: string | null;
}

interface RecurringTransactionFormProps {
  defaultValues?: Partial<RecurringFormState>;
  onSubmit: (data: RecurringFormState) => void;
  onCancel: () => void;
}

const RecurringTransactionForm = ({ 
  defaultValues, 
  onSubmit, 
  onCancel 
}: RecurringTransactionFormProps) => {
  const [description, setDescription] = useState(defaultValues?.description || "");
  const [amount, setAmount] = useState(defaultValues?.amount || "");
  const [isExpense, setIsExpense] = useState(defaultValues?.isExpense !== false);
  const [frequency, setFrequency] = useState<FrequencyType>(defaultValues?.frequency || "monthly");
  const [startDate, setStartDate] = useState<Date | null>(defaultValues?.startDate ? new Date(defaultValues.startDate) : null);
  const [endDate, setEndDate] = useState<Date | null>(defaultValues?.endDate ? new Date(defaultValues.endDate) : null);
  const [categoryId, setCategoryId] = useState<string | null>(defaultValues?.categoryId || null);
  const { user } = useAuth();

  const { data: categories } = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("categories")
        .select("*")
        .eq("is_expense", true)
        .order("name");

      if (error) throw error;
      return data as Category[];
    },
  });
  
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    if (!description || !amount || !frequency || !startDate) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }
    
    try {
      const formattedStartDate = format(startDate, 'yyyy-MM-dd');
      let formattedEndDate = null;
      
      if (endDate) {
        formattedEndDate = format(endDate, 'yyyy-MM-dd');
      }
      
      onSubmit({
        description,
        amount,
        isExpense,
        frequency,
        startDate: formattedStartDate,
        endDate: formattedEndDate,
        categoryId
      });
    } catch (error) {
      console.error("Form submission error:", error);
      toast({
        title: "Error",
        description: "There was a problem saving your transaction. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleIsExpenseChange = (checked: CheckedState) => {
    setIsExpense(checked === true);
  };

  return (
    <form onSubmit={handleSubmit} className="grid gap-4">
      <div className="grid gap-2">
        <Label htmlFor="description">Description</Label>
        <Input
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
        />
      </div>

      <CurrencyInput
        value={amount}
        onChange={setAmount}
      />

      <div className="grid gap-2">
        <Label htmlFor="isExpense">Expense?</Label>
        <Checkbox
          id="isExpense"
          checked={isExpense}
          onCheckedChange={handleIsExpenseChange}
        />
      </div>

      <div className="grid gap-2">
        <Label htmlFor="frequency">Frequency</Label>
        <Select value={frequency} onValueChange={(value) => setFrequency(value as FrequencyType)}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="Select a frequency" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="daily">Daily</SelectItem>
            <SelectItem value="weekly">Weekly</SelectItem>
            <SelectItem value="biweekly">Biweekly</SelectItem>
            <SelectItem value="monthly">Monthly</SelectItem>
            <SelectItem value="quarterly">Quarterly</SelectItem>
            <SelectItem value="annually">Annually</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid gap-2">
        <Label>Start Date</Label>
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant={"outline"}
              className={cn(
                "w-full justify-start text-left font-normal",
                !startDate && "text-muted-foreground"
              )}
            >
              {startDate ? format(startDate, "PPP") : (
                <span>Pick a date</span>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="center" side="bottom">
            <Calendar
              mode="single"
              selected={startDate}
              onSelect={setStartDate}
              disabled={(date) =>
                date > new Date()
              }
              initialFocus
            />
          </PopoverContent>
        </Popover>
      </div>

      <div className="grid gap-2">
        <Label>End Date (Optional)</Label>
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant={"outline"}
              className={cn(
                "w-full justify-start text-left font-normal",
                !endDate && "text-muted-foreground"
              )}
            >
              {endDate ? format(endDate, "PPP") : <span>Pick a date</span>}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="center" side="bottom">
            <Calendar
              mode="single"
              selected={endDate}
              onSelect={setEndDate}
              disabled={(date) =>
                date < (startDate || new Date())
              }
              initialFocus
            />
          </PopoverContent>
        </Popover>
      </div>

      <div className="grid gap-2">
        <Label htmlFor="categoryId">Category (Optional)</Label>
        <Select value={categoryId || ""} onValueChange={setCategoryId}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="Select a category" />
          </SelectTrigger>
          <SelectContent>
            {categories?.map((category) => (
              <SelectItem key={category.id} value={category.id}>
                {category.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="flex justify-end gap-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">
          Save
        </Button>
      </div>
    </form>
  );
};

export default RecurringTransactionForm;
