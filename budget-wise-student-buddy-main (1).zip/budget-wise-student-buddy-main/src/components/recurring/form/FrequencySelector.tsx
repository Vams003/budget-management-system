
import React from "react";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { FrequencyType } from "@/types/supabase-rpc";

interface FrequencySelectorProps {
  value: FrequencyType;
  onChange: (value: FrequencyType) => void;
  id?: string;
}

const FrequencySelector = ({
  value,
  onChange,
  id = "frequency",
}: FrequencySelectorProps) => {
  return (
    <div className="grid gap-2">
      <Label htmlFor={id}>Frequency</Label>
      <Select value={value} onValueChange={(v) => onChange(v as FrequencyType)}>
        <SelectTrigger id={id}>
          <SelectValue placeholder="Select frequency" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="daily">Daily</SelectItem>
          <SelectItem value="weekly">Weekly</SelectItem>
          <SelectItem value="biweekly">Bi-weekly</SelectItem>
          <SelectItem value="monthly">Monthly</SelectItem>
          <SelectItem value="quarterly">Quarterly</SelectItem>
          <SelectItem value="annually">Annually</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
};

export default FrequencySelector;
