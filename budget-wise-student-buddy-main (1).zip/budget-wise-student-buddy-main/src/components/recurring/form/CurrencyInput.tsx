
import React from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { useCurrency } from "@/hooks/use-currency";

interface CurrencyInputProps {
  value: string;
  onChange: (value: string) => void;
  id?: string;
  label?: string;
}

const CurrencyInput = ({ 
  value, 
  onChange, 
  id = "amount", 
  label = "Amount"
}: CurrencyInputProps) => {
  const { currencyCode, currencies } = useCurrency();
  const currencySymbol = currencies.find(c => c.code === currencyCode)?.symbol || currencyCode;

  return (
    <div className="grid gap-2">
      <Label htmlFor={id}>{label} ({currencySymbol})</Label>
      <Input
        id={id}
        type="number"
        step="0.01"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        required
      />
    </div>
  );
};

export default CurrencyInput;
