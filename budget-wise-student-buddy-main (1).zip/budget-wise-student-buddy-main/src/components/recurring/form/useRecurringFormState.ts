
import { useState } from "react";
import { RecurringTransaction } from "@/types/database";
import { FrequencyType } from "@/types/supabase-rpc";

export interface RecurringFormState {
  amount: string;
  description: string;
  categoryId: string;
  isExpense: boolean;
  frequency: FrequencyType;
  startDate: Date | null;
  endDate: Date | null;
  showEndDate: boolean;
  resetForm: () => void;
  setAmount: (value: string) => void;
  setDescription: (value: string) => void;
  setCategoryId: (value: string) => void;
  setIsExpense: (value: boolean) => void;
  setFrequency: (value: FrequencyType) => void;
  setStartDate: (value: Date | null) => void;
  setEndDate: (value: Date | null) => void;
  setShowEndDate: (value: boolean) => void;
}

export function useRecurringFormState(recurringTransaction?: RecurringTransaction | null): RecurringFormState {
  // Initialize form state from the recurring transaction or default values
  const [amount, setAmount] = useState<string>(
    recurringTransaction ? recurringTransaction.amount.toString() : ""
  );
  
  const [description, setDescription] = useState<string>(
    recurringTransaction?.description || ""
  );
  
  const [categoryId, setCategoryId] = useState<string>(
    recurringTransaction?.category_id || "uncategorized"
  );
  
  const [isExpense, setIsExpense] = useState<boolean>(
    recurringTransaction ? recurringTransaction.is_expense : true
  );
  
  const [frequency, setFrequency] = useState<FrequencyType>(
    recurringTransaction ? recurringTransaction.frequency as FrequencyType : "monthly"
  );
  
  const [startDate, setStartDate] = useState<Date | null>(
    recurringTransaction?.start_date ? new Date(recurringTransaction.start_date) : new Date()
  );
  
  const [endDate, setEndDate] = useState<Date | null>(
    recurringTransaction?.end_date ? new Date(recurringTransaction.end_date) : null
  );
  
  const [showEndDate, setShowEndDate] = useState<boolean>(
    !!recurringTransaction?.end_date
  );

  // Reset form to default values
  const resetForm = () => {
    setAmount("");
    setDescription("");
    setCategoryId("uncategorized");
    setIsExpense(true);
    setFrequency("monthly");
    setStartDate(new Date());
    setEndDate(null);
    setShowEndDate(false);
  };

  return {
    amount,
    description,
    categoryId,
    isExpense,
    frequency,
    startDate,
    endDate,
    showEndDate,
    resetForm,
    setAmount,
    setDescription,
    setCategoryId,
    setIsExpense,
    setFrequency,
    setStartDate,
    setEndDate,
    setShowEndDate,
  };
}
