
import { useCurrency } from "@/hooks/use-currency";

interface CurrencyDisplayProps {
  amount: number;
  showSecondary?: boolean;
  className?: string;
}

export function CurrencyDisplay({ 
  amount, 
  showSecondary = false, // Updated to false since we're removing secondary currency display
  className = ""
}: CurrencyDisplayProps) {
  const { formatCurrency } = useCurrency();
  
  const formattedValue = formatCurrency(amount);

  return (
    <span className={className}>
      {formattedValue}
    </span>
  );
}
