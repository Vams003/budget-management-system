
import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  LogOut,
  BadgeDollarSign,
  PiggyBank,
  Settings,
  Receipt,
  Menu,
  RefreshCw,
} from "lucide-react";
import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { useIsMobile } from "@/hooks/use-mobile";

const navItems = [
  {
    title: "Dashboard",
    href: "/dashboard",
    icon: LayoutDashboard,
  },
  {
    title: "Transactions",
    href: "/transactions",
    icon: Receipt,
  },
  {
    title: "Recurring",
    href: "/recurring",
    icon: RefreshCw,
  },
  {
    title: "Budget",
    href: "/budget",
    icon: BadgeDollarSign,
  },
  {
    title: "Savings",
    href: "/savings",
    icon: PiggyBank,
  },
  {
    title: "Settings",
    href: "/settings",
    icon: Settings,
  },
];

interface DashboardLayoutProps {
  children: React.ReactNode;
}

const DashboardLayout = ({ children }: DashboardLayoutProps) => {
  const { user, signOut } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const isMobile = useIsMobile();

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-900">
      {/* Mobile Menu */}
      {isMobile && (
        <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="sm" className="md:hidden absolute top-4 left-4">
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-64">
            <SheetHeader className="text-left">
              <SheetTitle>Menu</SheetTitle>
            </SheetHeader>
            <div className="py-4">
              {navItems.map((item) => (
                <SheetClose asChild key={item.href}>
                  <NavLink
                    to={item.href}
                    className={({ isActive }) =>
                      cn(
                        "flex items-center space-x-2 py-2 px-4 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700",
                        isActive
                          ? "bg-gray-200 dark:bg-gray-700 font-medium"
                          : "text-gray-700 dark:text-gray-300"
                      )
                    }
                  >
                    <item.icon className="h-4 w-4" />
                    <span>{item.title}</span>
                  </NavLink>
                </SheetClose>
              ))}
              <SheetClose asChild>
                <Button
                  variant="ghost"
                  className="w-full justify-start mt-2"
                  onClick={signOut}
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Sign Out
                </Button>
              </SheetClose>
            </div>
          </SheetContent>
        </Sheet>
      )}

      {/* Sidebar (hidden on small screens) */}
      <div className="hidden md:flex flex-col w-64 bg-gray-50 dark:bg-gray-800 border-r dark:border-gray-700">
        <div className="flex items-center justify-center h-16 border-b dark:border-gray-700">
          <span className="text-lg font-semibold dark:text-white">
            Finance Tracker
          </span>
        </div>
        <div className="flex flex-col flex-grow p-4 space-y-2">
          {navItems.map((item) => (
            <NavLink
              key={item.href}
              to={item.href}
              className={({ isActive }) =>
                cn(
                  "flex items-center space-x-2 py-2 px-4 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700",
                  isActive
                    ? "bg-gray-200 dark:bg-gray-700 font-medium"
                    : "text-gray-700 dark:text-gray-300"
                )
              }
            >
              <item.icon className="h-4 w-4" />
              <span>{item.title}</span>
            </NavLink>
          ))}
        </div>
        <div className="p-4 border-t dark:border-gray-700">
          <Button variant="ghost" className="w-full justify-start" onClick={signOut}>
            <LogOut className="h-4 w-4 mr-2" />
            Sign Out
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex flex-col flex-grow overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between h-16 bg-white dark:bg-gray-800 border-b dark:border-gray-700 px-4">
          <h1 className="text-lg font-medium dark:text-white">
            {navItems.find((item) => item.href === window.location.pathname)?.title ||
              "Dashboard"}
          </h1>
          <Avatar>
            <AvatarImage src={user?.user_metadata?.avatar_url as string} />
            <AvatarFallback>{user?.email?.charAt(0).toUpperCase()}</AvatarFallback>
          </Avatar>
        </div>

        {/* Page Content */}
        <div className="flex-grow p-6">
          {children}
        </div>
      </div>
    </div>
  );
};

export default DashboardLayout;
