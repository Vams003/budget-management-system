
import { useNavigate, useLocation } from "react-router-dom";
import { LayoutDashboard, BadgeDollarSign, PiggyBank, Settings, Receipt, RefreshCw } from "lucide-react";
import { cn } from "@/lib/utils";

export function MobileNavigation() {
  const navigate = useNavigate();
  const location = useLocation();
  
  const navItems = [
    {
      name: "Dashboard",
      href: "/",
      icon: LayoutDashboard,
    },
    {
      name: "Transactions",
      href: "/transactions",
      icon: Receipt,
    },
    {
      name: "Recurring",
      href: "/recurring",
      icon: RefreshCw,
    },
    {
      name: "Budget",
      href: "/budget",
      icon: BadgeDollarSign,
    },
    {
      name: "Savings",
      href: "/savings",
      icon: PiggyBank,
    },
    {
      name: "Settings",
      href: "/settings",
      icon: Settings,
    },
  ];

  return (
    <div className="fixed bottom-0 left-0 z-40 w-full h-16 bg-background border-t md:hidden">
      <div className="grid h-full grid-cols-6">
        {navItems.map((item) => (
          <button
            key={item.href}
            type="button"
            className="flex flex-col items-center justify-center px-1"
            onClick={() => navigate(item.href)}
          >
            <item.icon
              className={cn(
                "h-5 w-5 mb-1",
                location.pathname === item.href
                  ? "text-primary"
                  : "text-muted-foreground"
              )}
            />
            <span
              className={cn(
                "text-xs truncate",
                location.pathname === item.href
                  ? "text-primary font-medium"
                  : "text-muted-foreground"
              )}
            >
              {item.name}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}
