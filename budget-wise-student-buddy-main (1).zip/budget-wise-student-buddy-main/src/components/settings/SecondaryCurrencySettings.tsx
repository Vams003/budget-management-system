
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useCurrency } from "@/hooks/use-currency";

export function SecondaryCurrencySettings() {
  const { currencyCode, secondaryCurrency, updateSecondaryCurrency, currencies } = useCurrency();
  const [showSecondary, setShowSecondary] = useState(Boolean(secondaryCurrency));

  const handleToggleSecondary = (checked: boolean) => {
    setShowSecondary(checked);
    if (!checked) {
      updateSecondaryCurrency("");
    } else if (!secondaryCurrency) {
      // Set default secondary currency
      const defaultSecondary = currencyCode === "USD" ? "EUR" : "USD";
      updateSecondaryCurrency(defaultSecondary);
    }
  };

  const handleCurrencyChange = (value: string) => {
    updateSecondaryCurrency(value);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Secondary Currency</CardTitle>
        <CardDescription>
          View approximate values in a secondary currency
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <Label htmlFor="show-secondary">Show secondary currency</Label>
          <Switch 
            id="show-secondary"
            checked={showSecondary} 
            onCheckedChange={handleToggleSecondary}
          />
        </div>
        
        {showSecondary && (
          <div className="space-y-2 pt-2">
            <Label htmlFor="secondary-currency">Select secondary currency</Label>
            <Select
              value={secondaryCurrency}
              onValueChange={handleCurrencyChange}
              disabled={!showSecondary}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select currency" />
              </SelectTrigger>
              <SelectContent>
                {currencies
                  .filter(currency => currency.code !== currencyCode)
                  .map((currency) => (
                    <SelectItem key={currency.code} value={currency.code}>
                      {currency.symbol} - {currency.name} ({currency.code})
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default SecondaryCurrencySettings;
