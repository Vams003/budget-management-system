
import { useState } from "react";
import { CSVLink } from "react-csv";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { FileText, Download } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { Transaction, Budget } from "@/types/database";

interface ExportDataProps {
  transactions: Transaction[] | undefined;
  budgets: Budget[] | undefined;
}

const ExportData = ({ transactions, budgets }: ExportDataProps) => {
  // Prepare transaction data for CSV export
  const transactionsCsvData = transactions ? transactions.map(t => ({
    Date: new Date(t.transaction_date).toLocaleDateString(),
    Description: t.description || "",
    Category: t.category_name,
    Amount: t.amount,
    Type: t.is_expense ? "Expense" : "Income",
  })) : [];

  // Prepare budget data for CSV export
  const budgetsCsvData = budgets ? budgets.map(b => ({
    Month: b.month,
    Year: b.year,
    Amount: b.amount,
  })) : [];

  // Generate PDF for transactions
  const generateTransactionsPDF = () => {
    if (!transactions || transactions.length === 0) {
      toast({
        title: "No transactions",
        description: "There are no transactions to export.",
        variant: "destructive",
      });
      return;
    }

    const doc = new jsPDF();
    doc.text("Your Transactions", 14, 16);
    
    // Add current date
    const date = new Date().toLocaleDateString();
    doc.setFontSize(10);
    doc.text(`Generated on: ${date}`, 14, 22);
    
    // Create table with transactions
    const tableColumn = ["Date", "Description", "Category", "Amount", "Type"];
    const tableRows = transactions.map(t => [
      new Date(t.transaction_date).toLocaleDateString(),
      t.description || "",
      t.category_name,
      `$${t.amount.toFixed(2)}`,
      t.is_expense ? "Expense" : "Income",
    ]);

    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: 30,
      theme: 'striped',
      headStyles: { fillColor: [41, 128, 185] },
    });

    doc.save("transactions.pdf");
    
    toast({
      title: "PDF generated",
      description: "Your transactions have been exported to PDF.",
    });
  };

  // Generate PDF for budgets
  const generateBudgetsPDF = () => {
    if (!budgets || budgets.length === 0) {
      toast({
        title: "No budgets",
        description: "There are no budgets to export.",
        variant: "destructive",
      });
      return;
    }

    const doc = new jsPDF();
    doc.text("Your Budgets", 14, 16);
    
    // Add current date
    const date = new Date().toLocaleDateString();
    doc.setFontSize(10);
    doc.text(`Generated on: ${date}`, 14, 22);
    
    // Create table with budgets
    const tableColumn = ["Month", "Year", "Budget Amount"];
    const tableRows = budgets.map(b => [
      b.month.toString(),
      b.year.toString(),
      `$${b.amount.toFixed(2)}`,
    ]);

    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: 30,
      theme: 'striped',
      headStyles: { fillColor: [41, 128, 185] },
    });

    doc.save("budgets.pdf");
    
    toast({
      title: "PDF generated",
      description: "Your budgets have been exported to PDF.",
    });
  };

  const handleCSVExport = () => {
    toast({
      title: "CSV Export Started",
      description: "Your data is being prepared for download.",
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Export Data</CardTitle>
        <CardDescription>
          Download your financial data for backup or analysis
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h3 className="text-lg font-medium">Transaction Data</h3>
          <p className="text-sm text-muted-foreground mb-3">
            Export all your transaction records
          </p>
          <div className="flex flex-wrap gap-3">
            <CSVLink 
              data={transactionsCsvData} 
              filename={"transactions.csv"}
              className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2"
              onClick={handleCSVExport}
            >
              <FileText className="mr-2 h-4 w-4" />
              Export as CSV
            </CSVLink>
            
            <Button variant="outline" onClick={generateTransactionsPDF}>
              <Download className="mr-2 h-4 w-4" />
              Export as PDF
            </Button>
          </div>
        </div>
        
        <Separator className="my-4" />
        
        <div>
          <h3 className="text-lg font-medium">Budget Data</h3>
          <p className="text-sm text-muted-foreground mb-3">
            Export all your budget records
          </p>
          <div className="flex flex-wrap gap-3">
            <CSVLink 
              data={budgetsCsvData} 
              filename={"budgets.csv"}
              className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2"
              onClick={handleCSVExport}
            >
              <FileText className="mr-2 h-4 w-4" />
              Export as CSV
            </CSVLink>
            
            <Button variant="outline" onClick={generateBudgetsPDF}>
              <Download className="mr-2 h-4 w-4" />
              Export as PDF
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ExportData;
