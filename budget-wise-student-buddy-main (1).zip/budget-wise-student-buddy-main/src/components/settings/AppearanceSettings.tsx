
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Moon, Sun } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface AppearanceSettingsProps {
  isDarkMode: boolean;
  setIsDarkMode: (isDark: boolean) => void;
}

const AppearanceSettings = ({ isDarkMode, setIsDarkMode }: AppearanceSettingsProps) => {
  const handleToggleDarkMode = () => {
    const newDarkModeState = !isDarkMode;
    setIsDarkMode(newDarkModeState);
    
    if (newDarkModeState) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("darkMode", "true");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("darkMode", "false");
    }
    
    toast({
      title: newDarkModeState ? "Dark mode enabled" : "Light mode enabled",
      description: "Your preference has been saved.",
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Appearance</CardTitle>
        <CardDescription>
          Customize the look and feel of the application
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {isDarkMode ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
            <span>Dark Mode</span>
          </div>
          <Switch 
            checked={isDarkMode}
            onCheckedChange={handleToggleDarkMode}
          />
        </div>
      </CardContent>
    </Card>
  );
};

export default AppearanceSettings;
