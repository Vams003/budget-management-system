
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { useCurrency } from "@/hooks/use-currency";
import { useToast } from "@/hooks/use-toast";

export function CurrencySettings() {
  const { currencyCode, updateCurrency, currencies } = useCurrency();
  const { toast } = useToast();
  const [selectedCurrency, setSelectedCurrency] = useState(currencyCode);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleCurrencyChange = async () => {
    if (selectedCurrency === currencyCode) return;

    setIsSubmitting(true);
    const success = await updateCurrency(selectedCurrency);
    
    if (success) {
      toast({
        title: "Currency updated",
        description: "Your preferred currency has been updated successfully.",
      });
    } else {
      toast({
        title: "Error",
        description: "Failed to update currency. Please try again.",
        variant: "destructive",
      });
    }
    setIsSubmitting(false);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Currency Settings</CardTitle>
        <CardDescription>
          Change the currency used throughout the application.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="currency">Select Currency</Label>
          <Select
            value={selectedCurrency}
            onValueChange={setSelectedCurrency}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select currency" />
            </SelectTrigger>
            <SelectContent>
              {currencies.map((currency) => (
                <SelectItem key={currency.code} value={currency.code}>
                  {currency.symbol} - {currency.name} ({currency.code})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <Button 
          onClick={handleCurrencyChange} 
          disabled={isSubmitting || selectedCurrency === currencyCode}
          className="w-full"
        >
          {isSubmitting ? "Saving..." : "Save Currency Preference"}
        </Button>
      </CardContent>
    </Card>
  );
}

export default CurrencySettings;
