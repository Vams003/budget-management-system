
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Category } from "@/types/database";
import { CurrencyDisplay } from "@/components/ui/currency-display";
import { cn } from "@/lib/utils";

interface BudgetCategoryCardProps {
  category: Category;
  spent: number;
  percentage: number;
  budgetAmount: number;
  isOverBudget: boolean;
  isNearLimit: boolean;
  suggestion: string | null;
  formatCurrency: (amount: number) => string;
  onSetBudget: (category: Category) => void;
}

const BudgetCategoryCard = ({
  category,
  spent,
  percentage,
  budgetAmount,
  isOverBudget,
  isNearLimit,
  suggestion,
  formatCurrency,
  onSetBudget,
}: BudgetCategoryCardProps) => {
  return (
    <Card className={cn(
      "overflow-hidden",
      isOverBudget && "border-red-400",
      isNearLimit && !isOverBudget && "border-yellow-400"
    )}>
      <div
        className="h-2"
        style={{ backgroundColor: category.color || '#888888' }}
      />
      <CardContent className="p-4">
        <div className="flex justify-between items-center mb-2">
          <h3 className="font-semibold">{category.name}</h3>
          <span className={cn(
            "text-sm font-medium",
            isOverBudget ? "text-red-500" : "text-green-500"
          )}>
            {percentage > 0 ? `${percentage.toFixed(0)}%` : "0%"}
          </span>
        </div>
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Spent:</span>
            <span className="font-medium"><CurrencyDisplay amount={spent} showSecondary={false} /></span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Budget:</span>
            <span className="font-medium">
              {budgetAmount > 0 ? <CurrencyDisplay amount={budgetAmount} showSecondary={false} /> : "Not set"}
            </span>
          </div>
          <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
            <div
              className={cn(
                "h-full",
                isOverBudget ? "bg-red-500" : isNearLimit ? "bg-yellow-500" : "bg-green-500"
              )}
              style={{ width: `${Math.min(percentage, 100)}%` }}
            />
          </div>
        </div>
        {suggestion && (
          <div className="mt-3 p-2 bg-blue-50 dark:bg-blue-950 text-blue-800 dark:text-blue-200 text-xs rounded-md">
            <p>{suggestion}</p>
          </div>
        )}
      </CardContent>
      <CardFooter className="px-4 py-3 bg-gray-50 dark:bg-gray-900">
        <Button 
          variant="outline" 
          className="w-full text-sm"
          onClick={() => onSetBudget(category)}
        >
          {budgetAmount > 0 ? "Update Budget" : "Set Budget"}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default BudgetCategoryCard;
