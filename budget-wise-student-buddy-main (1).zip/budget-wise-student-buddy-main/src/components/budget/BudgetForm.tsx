
import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Category } from "@/types/database";
import { useCurrency } from "@/hooks/use-currency";
import CurrencyInput from "@/components/recurring/form/CurrencyInput";

interface BudgetFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedCategory: Category | null;
  budgetAmount: string;
  onBudgetAmountChange: (value: string) => void;
  onSaveBudget: () => void;
}

const BudgetForm = ({
  open,
  onOpenChange,
  selectedCategory,
  budgetAmount,
  onBudgetAmountChange,
  onSaveBudget
}: BudgetFormProps) => {
  const { currencyCode } = useCurrency();

  const handleSave = () => {
    onSaveBudget();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Set Budget for {selectedCategory?.name}</DialogTitle>
          <DialogDescription>
            Set a monthly budget limit for this category.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <CurrencyInput
            id="budget-amount"
            label="Budget Amount"
            value={budgetAmount}
            onChange={onBudgetAmountChange}
          />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave}>Save Budget</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default BudgetForm;
