
// Types for RPC function parameters
export interface GetExchangeRatesParams {
  // This RPC function doesn't require any parameters
  [key: string]: never;
}

export interface CreateRecurringTransactionParams {
  user_id: string;
  description: string;
  amount: number;
  is_expense: boolean;
  frequency: FrequencyType;
  start_date: string;
  end_date?: string | null;
  category_id?: string | null;
}

export interface UpdateRecurringTransactionParams {
  transaction_id: string;
  user_id: string;
  description: string;
  amount: number;
  is_expense: boolean;
  frequency: FrequencyType;
  start_date: string;
  end_date?: string | null;
  category_id?: string | null; 
}

export interface GetRecurringTransactionsParams {
  user_id_param: string;
}

export interface DeleteRecurringTransactionParams {
  transaction_id_param: string;
  user_id_param: string;
}

// Frequency type for recurring transactions
export type FrequencyType = 'daily' | 'weekly' | 'biweekly' | 'monthly' | 'quarterly' | 'annually';
