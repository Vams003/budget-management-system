
import { 
  useToast as useToastOriginal, 
  toast as toastOriginal,
  ToastProvider as ToastProviderOriginal,
  type Toast,
  type ToastActionProps,
  type ToastPropsWithoutId 
} from "@/components/ui/use-toast";

export type { Toast, ToastActionProps, ToastPropsWithoutId };

export const useToast = useToastOriginal;
export const toast = toastOriginal;
export const ToastProvider = ToastProviderOriginal;
