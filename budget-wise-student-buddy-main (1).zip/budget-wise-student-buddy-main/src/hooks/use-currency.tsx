
import { useState, useEffect, useCallback } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { currencies } from "@/types/database";
import { useToast } from "@/hooks/use-toast";

export function useCurrency() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [currencyCode, setCurrencyCode] = useState<string>("USD");
  const [isLoading, setIsLoading] = useState(true);
  const [secondaryCurrency, setSecondaryCurrency] = useState<string>("");

  useEffect(() => {
    const fetchCurrency = async () => {
      if (user) {
        setIsLoading(true);
        try {
          // Fix: Remove generic type parameter from supabase.from
          const { data, error } = await supabase
            .from("profiles")
            .select("*")
            .eq("id", user.id)
            .single();

          if (!error && data && data.currency) {
            setCurrencyCode(data.currency);
            
            if (data.currency !== "EUR") {
              setSecondaryCurrency("EUR");
            } else {
              setSecondaryCurrency("USD");
            }
          }
        } catch (error: any) {
          console.error("Error fetching currency:", error);
        } finally {
          setIsLoading(false);
        }
      }
    };

    fetchCurrency();
  }, [user]);

  const updateCurrency = useCallback(async (code: string) => {
    if (!user) return false;

    try {
      // Fix: Remove generic type parameter from supabase.from
      const { error } = await supabase.from('profiles')
        .update({ currency: code })
        .eq('id', user.id);

      if (error) throw error;
      setCurrencyCode(code);
      return true;
    } catch (error: any) {
      console.error("Error updating currency:", error);
      return false;
    }
  }, [user]);

  const updateSecondaryCurrency = useCallback((code: string) => {
    setSecondaryCurrency(code);
  }, []);

  const formatCurrency = useCallback((amount: number, targetCurrency?: string) => {
    const currency = currencies.find(c => c.code === (targetCurrency || currencyCode)) || currencies[0];
    
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: currency.code,
      currencyDisplay: "symbol",
    }).format(amount);
  }, [currencyCode]);

  const formatWithSecondaryCurrency = useCallback((amount: number) => {
    if (!secondaryCurrency || currencyCode === secondaryCurrency) {
      return formatCurrency(amount);
    }

    return formatCurrency(amount);
  }, [currencyCode, secondaryCurrency, formatCurrency]);

  const convertCurrency = useCallback((amount: number, fromCurrency: string, toCurrency: string) => {
    // Since we're removing exchange rates, we'll just return the original amount
    return amount;
  }, []);

  return {
    currencyCode,
    secondaryCurrency,
    updateCurrency,
    updateSecondaryCurrency,
    formatCurrency,
    formatWithSecondaryCurrency,
    convertCurrency,
    currencies,
    isLoading
  };
}
