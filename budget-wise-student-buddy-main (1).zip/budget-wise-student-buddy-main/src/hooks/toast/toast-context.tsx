
import * as React from "react";
import { actionTypes, TOAST_REMOVE_DELAY } from "./constants";
import { 
  ToastContextValue, 
  ToastProviderProps, 
  ToastPropsWithoutId, 
  State, 
  ToastProps
} from "./types";
import { genId, reducer, toastTimeouts } from "./toast-reducer";

const ToastContext = React.createContext<ToastContextValue | undefined>(undefined);

export function ToastProvider({ children }: ToastProviderProps) {
  const [state, dispatch] = React.useReducer(reducer, {
    toasts: [],
  });

  React.useEffect(() => {
    state.toasts.forEach((toast) => {
      if (toast.open === false && !toastTimeouts.has(toast.id)) {
        const timeout = setTimeout(() => {
          dispatch({
            type: actionTypes.REMOVE_TOAST,
            toastId: toast.id,
          });
        }, TOAST_REMOVE_DELAY);

        toastTimeouts.set(toast.id, timeout);
      }
    });
  }, [state.toasts]);

  const addToast = React.useCallback(
    (toast: ToastPropsWithoutId) => {
      const id = genId();
      
      dispatch({
        type: actionTypes.ADD_TOAST,
        toast: {
          ...toast,
          open: true,
        },
      });
      
      return id;
    },
    [dispatch]
  );

  const updateToast = React.useCallback(
    (toast: Partial<ToastPropsWithoutId> & { id: string }) => {
      dispatch({
        type: actionTypes.UPDATE_TOAST,
        toast,
      });
    },
    [dispatch]
  );

  const dismissToast = React.useCallback(
    (toastId?: string) => {
      dispatch({
        type: actionTypes.DISMISS_TOAST,
        toastId,
      });
    },
    [dispatch]
  );

  const removeToast = React.useCallback(
    (toastId?: string) => {
      dispatch({
        type: actionTypes.REMOVE_TOAST,
        toastId,
      });
    },
    [dispatch]
  );

  return (
    <ToastContext.Provider
      value={{
        toasts: state.toasts,
        addToast,
        updateToast,
        dismissToast,
        removeToast,
      }}
    >
      {children}
    </ToastContext.Provider>
  );
}

export function useToast() {
  const context = React.useContext(ToastContext);

  if (!context) {
    throw new Error("useToast must be used within a ToastProvider");
  }

  return {
    ...context,
    toast: (props: ToastPropsWithoutId) => {
      context.addToast(props);
    },
  };
}

export function toast(props: ToastPropsWithoutId) {
  // This is a placeholder for direct import usage
  console.warn("Direct toast call outside React components is not supported");
  return null;
}
