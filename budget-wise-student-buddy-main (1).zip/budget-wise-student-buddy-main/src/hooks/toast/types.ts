
import * as React from "react";
import type { ToastProps as ToastPrimitiveProps } from "@radix-ui/react-toast";
import type { ToastActionElement } from "@/components/ui/toast";

export type ToastProps = Omit<
  ToastPrimitiveProps,
  "type" | "duration"
> & {
  id: string;
  title?: React.ReactNode;
  description?: React.ReactNode;
  action?: ToastActionElement;
  duration?: number;
  variant?: "default" | "destructive";
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
};

export type ToastPropsWithoutId = Omit<ToastProps, "id">;

export type ToastActionProps = React.ComponentPropsWithoutRef<"button">;

export type Toast = Omit<ToastProps, "id"> & {
  id?: string;
};

export const TOAST_LIMIT = 20;
export const TOAST_REMOVE_DELAY = 1000;

export const actionTypes = {
  ADD_TOAST: "ADD_TOAST",
  UPDATE_TOAST: "UPDATE_TOAST",
  DISMISS_TOAST: "DISMISS_TOAST",
  REMOVE_TOAST: "REMOVE_TOAST",
} as const;

export type ActionType = typeof actionTypes;

export type Action =
  | {
      type: ActionType["ADD_TOAST"];
      toast: ToastPropsWithoutId;
    }
  | {
      type: ActionType["UPDATE_TOAST"];
      toast: Partial<ToastPropsWithoutId> & { id: string };
    }
  | {
      type: ActionType["DISMISS_TOAST"];
      toastId?: string;
    }
  | {
      type: ActionType["REMOVE_TOAST"];
      toastId?: string;
    };

export interface State {
  toasts: ToastProps[];
}

export interface ToastContextValue {
  toasts: ToastProps[];
  addToast: (props: ToastPropsWithoutId) => string;
  updateToast: (props: Partial<ToastPropsWithoutId> & { id: string }) => void;
  dismissToast: (toastId?: string) => void;
  removeToast: (toastId?: string) => void;
}

export interface ToastProviderProps {
  children: React.ReactNode;
}
