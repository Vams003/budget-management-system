import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { toast } from "@/hooks/use-toast";
import { RecurringTransaction } from "@/types/database";
import {
  CreateRecurringTransactionParams,
  UpdateRecurringTransactionParams,
  DeleteRecurringTransactionParams,
  FrequencyType,
  GetRecurringTransactionsParams
} from "@/types/supabase-rpc";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Pencil, Trash2 } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { format, parseISO } from 'date-fns';
import RecurringTransactionForm from "@/components/recurring/form/RecurringTransactionForm";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useCurrency } from "@/hooks/use-currency";
import { callRPC } from "@/lib/supabase-helpers";

interface RecurringFormState {
  description: string;
  amount: string;
  isExpense: boolean;
  frequency: FrequencyType;
  startDate: string;
  endDate: string | null;
  categoryId: string | null;
}

const RecurringTransactions = () => {
  const { user } = useAuth();
  const [showForm, setShowForm] = useState(false);
  const [formAction, setFormAction] = useState<"create" | "update">("create");
  const [editingTransaction, setEditingTransaction] =
    useState<RecurringTransaction | null>(null);
  const { formatCurrency } = useCurrency();

  const {
    data: transactions,
    isLoading,
    refetch: refetchTransactions,
  } = useQuery({
    queryKey: ["recurring-transactions"],
    queryFn: async () => {
      if (!user) return [];

      const params: GetRecurringTransactionsParams = { user_id_param: user.id };
      const { data, error } = await callRPC("get_recurring_transactions", params);

      if (error) throw error;
      return (data || []) as RecurringTransaction[];
    },
  });

  const handleDelete = async (id: string) => {
    if (!user) return;

    try {
      const params: DeleteRecurringTransactionParams = {
        transaction_id_param: id,
        user_id_param: user.id
      };

      const { error } = await callRPC("delete_recurring_transaction", params);

      if (error) throw error;

      toast({
        title: "Transaction Deleted",
        description: "The recurring transaction has been deleted."
      });

      refetchTransactions();
    } catch (error: any) {
      console.error("Delete error:", error);
      toast({
        title: "Error",
        description: `Failed to delete: ${error.message}`,
        variant: "destructive"
      });
    }
  };

  const handleEdit = (transaction: RecurringTransaction) => {
    setEditingTransaction(transaction);
    setFormAction("update");
    setShowForm(true);
  };

  const handleSubmit = async (formData: RecurringFormState) => {
    if (!user) return;

    try {
      console.log("Submitting form data:", formData);
      
      const transactionData = {
        user_id: user.id,
        description: formData.description,
        amount: parseFloat(formData.amount),
        is_expense: formData.isExpense,
        frequency: formData.frequency,
        start_date: formData.startDate,
        end_date: formData.endDate || null,
        category_id: formData.categoryId || null
      };
      
      if (formAction === "create") {
        console.log("Creating with transaction data:", transactionData);
        
        const { data, error } = await callRPC("create_recurring_transaction", transactionData);
        console.log("Create response:", { data, error });

        if (error) throw error;

        toast({
          title: "Transaction Created",
          description: "Your recurring transaction has been created."
        });
      } else if (formAction === "update" && editingTransaction) {
        console.log("Updating with transaction data:", transactionData);
        
        const updateData = { 
          ...transactionData,
          transaction_id: editingTransaction.id
        };
        
        const { data, error } = await callRPC("update_recurring_transaction", updateData);
        console.log("Update response:", { data, error });

        if (error) throw error;

        toast({
          title: "Transaction Updated",
          description: "Your recurring transaction has been updated."
        });
      }

      setShowForm(false);
      setEditingTransaction(null);
      refetchTransactions();
    } catch (error: any) {
      console.error("Form submission error:", error);
      toast({
        title: "Error",
        description: `Failed to save: ${error.message}`,
        variant: "destructive"
      });
    }
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Recurring Transactions</h1>
        <Button onClick={() => {
          setFormAction("create");
          setEditingTransaction(null);
          setShowForm(true);
        }}>
          Add Transaction
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Transactions</CardTitle>
          <CardDescription>
            Manage your recurring transactions here.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p>Loading transactions...</p>
          ) : (
            <TooltipProvider>
              <Table>
                <TableCaption>
                  A list of your recurring transactions.
                </TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead>Description</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                    <TableHead>Frequency</TableHead>
                    <TableHead>Start Date</TableHead>
                    <TableHead>End Date</TableHead>
                    <TableHead className="text-center">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {transactions && transactions.length > 0 ? (
                    transactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell className="font-medium">
                          {transaction.description}
                        </TableCell>
                        <TableCell className="text-right">
                          {formatCurrency(transaction.amount)}
                        </TableCell>
                        <TableCell>{transaction.frequency}</TableCell>
                        <TableCell>
                          {format(parseISO(transaction.start_date), 'yyyy-MM-dd')}
                        </TableCell>
                        <TableCell>
                          {transaction.end_date
                            ? format(parseISO(transaction.end_date), 'yyyy-MM-dd')
                            : "N/A"}
                        </TableCell>
                        <TableCell className="text-center">
                          <div className="flex items-center justify-center space-x-2">
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleEdit(transaction)}
                                  >
                                    <Pencil className="h-4 w-4" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Edit</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleDelete(transaction.id)}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Delete</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell
                        colSpan={6}
                        className="text-center font-medium"
                      >
                        No recurring transactions found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TooltipProvider>
          )}
        </CardContent>
      </Card>

      {showForm && (
        <RecurringTransactionForm
          defaultValues={editingTransaction
            ? {
              description: editingTransaction.description || "",
              amount: editingTransaction.amount.toString(),
              isExpense: editingTransaction.is_expense,
              frequency: editingTransaction.frequency as FrequencyType,
              startDate: format(parseISO(editingTransaction.start_date), 'yyyy-MM-dd'),
              endDate: editingTransaction.end_date
                ? format(parseISO(editingTransaction.end_date), 'yyyy-MM-dd')
                : "",
              categoryId: editingTransaction.category_id || "",
            }
            : undefined
          }
          onSubmit={handleSubmit}
          onCancel={() => setShowForm(false)}
        />
      )}
    </div>
  );
};

export default RecurringTransactions;
