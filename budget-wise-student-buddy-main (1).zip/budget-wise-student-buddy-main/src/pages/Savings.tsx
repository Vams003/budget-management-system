
import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import { toast } from "@/hooks/use-toast";
import { CalendarIcon, PlusCircle, Pencil, Trash2, Target } from "lucide-react";
import { SavingsGoal, Transaction } from "@/types/database";

const Savings = () => {
  const { user } = useAuth();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [currentGoal, setCurrentGoal] = useState<SavingsGoal | null>(null);
  
  // Form state
  const [goalName, setGoalName] = useState("");
  const [targetAmount, setTargetAmount] = useState("");
  const [currentAmount, setCurrentAmount] = useState("");
  const [deadline, setDeadline] = useState<Date | undefined>(undefined);

  // Fetch savings goals
  const {
    data: savingsGoals,
    isLoading,
    refetch,
  } = useQuery({
    queryKey: ["savingsGoals"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("savings_goals")
        .select("*")
        .eq("user_id", user?.id)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as SavingsGoal[];
    },
  });

  // Fetch savings transactions
  const { data: savingsTransactions } = useQuery({
    queryKey: ["savingsTransactions"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("transactions")
        .select("*")
        .eq("user_id", user?.id)
        .eq("is_expense", true)
        .eq("category_id", "savings"); // Assuming there's a savings category

      if (error) throw error;
      return data as Transaction[];
    },
    enabled: !!user,
  });

  // Add new savings goal
  const handleAddGoal = async () => {
    const target = parseFloat(targetAmount);
    const current = parseFloat(currentAmount) || 0;
    
    if (!goalName || isNaN(target) || target <= 0) {
      toast({
        title: "Invalid input",
        description: "Please provide a name and a valid target amount.",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await supabase.from("savings_goals").insert({
        user_id: user?.id,
        name: goalName,
        target_amount: target,
        current_amount: current,
        deadline: deadline ? format(deadline, "yyyy-MM-dd") : null,
      });

      if (error) throw error;

      toast({
        title: "Savings goal added",
        description: `${goalName} has been added to your savings goals.`,
      });
      
      setShowAddDialog(false);
      resetForm();
      refetch();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  // Update savings goal
  const handleUpdateGoal = async () => {
    if (!currentGoal) return;
    
    const target = parseFloat(targetAmount);
    const current = parseFloat(currentAmount);
    
    if (!goalName || isNaN(target) || target <= 0 || isNaN(current)) {
      toast({
        title: "Invalid input",
        description: "Please provide valid values for all fields.",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await supabase
        .from("savings_goals")
        .update({
          name: goalName,
          target_amount: target,
          current_amount: current,
          deadline: deadline ? format(deadline, "yyyy-MM-dd") : null,
        })
        .eq("id", currentGoal.id);

      if (error) throw error;

      toast({
        title: "Savings goal updated",
        description: `${goalName} has been updated.`,
      });
      
      setShowEditDialog(false);
      resetForm();
      refetch();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  // Delete savings goal
  const handleDeleteGoal = async () => {
    if (!currentGoal) return;

    try {
      const { error } = await supabase
        .from("savings_goals")
        .delete()
        .eq("id", currentGoal.id);

      if (error) throw error;

      toast({
        title: "Savings goal deleted",
        description: `${currentGoal.name} has been deleted.`,
      });
      
      setShowDeleteDialog(false);
      setCurrentGoal(null);
      refetch();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  // Setup goal for editing
  const setupEditGoal = (goal: SavingsGoal) => {
    setCurrentGoal(goal);
    setGoalName(goal.name);
    setTargetAmount(goal.target_amount.toString());
    setCurrentAmount(goal.current_amount.toString());
    setDeadline(goal.deadline ? new Date(goal.deadline) : undefined);
    setShowEditDialog(true);
  };

  // Setup goal for deletion
  const setupDeleteGoal = (goal: SavingsGoal) => {
    setCurrentGoal(goal);
    setShowDeleteDialog(true);
  };

  // Reset form fields
  const resetForm = () => {
    setGoalName("");
    setTargetAmount("");
    setCurrentAmount("");
    setDeadline(undefined);
  };

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(amount);
  };

  // Calculate days remaining
  const calculateDaysRemaining = (deadlineStr: string | null) => {
    if (!deadlineStr) return null;
    
    const deadline = new Date(deadlineStr);
    const today = new Date();
    
    const diffTime = deadline.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays;
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Savings Goals</h1>
        <Button onClick={() => setShowAddDialog(true)}>
          <PlusCircle className="mr-2 h-4 w-4" />
          Add Goal
        </Button>
      </div>

      {isLoading ? (
        <div className="text-center py-10">Loading savings goals...</div>
      ) : !savingsGoals || savingsGoals.length === 0 ? (
        <Card className="text-center py-10">
          <CardContent>
            <Target className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <p className="mb-4">You don't have any savings goals yet.</p>
            <Button onClick={() => setShowAddDialog(true)}>
              <PlusCircle className="mr-2 h-4 w-4" />
              Create your first goal
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {savingsGoals.map((goal) => {
            const percentage = (goal.current_amount / goal.target_amount) * 100;
            const daysRemaining = calculateDaysRemaining(goal.deadline);
            
            return (
              <Card key={goal.id}>
                <CardHeader>
                  <CardTitle>{goal.name}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progress</span>
                      <span>
                        {formatCurrency(goal.current_amount)} of {formatCurrency(goal.target_amount)}
                      </span>
                    </div>
                    <Progress value={percentage} />
                    <div className="text-right text-xs text-muted-foreground">
                      {percentage.toFixed(1)}% complete
                    </div>
                  </div>
                  
                  {goal.deadline && (
                    <div className="bg-muted/40 p-3 rounded-md text-sm">
                      <div className="flex justify-between mb-1">
                        <span>Deadline</span>
                        <span>{format(new Date(goal.deadline), "MMM d, yyyy")}</span>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {daysRemaining !== null && (
                          <>
                            {daysRemaining > 0
                              ? `${daysRemaining} days remaining`
                              : daysRemaining === 0
                              ? "Due today"
                              : `Overdue by ${Math.abs(daysRemaining)} days`}
                          </>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
                <CardFooter className="justify-between border-t p-4">
                  <Button variant="ghost" size="icon" onClick={() => setupEditGoal(goal)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => setupDeleteGoal(goal)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            );
          })}
        </div>
      )}

      {/* Add Goal Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Savings Goal</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="goal-name">Goal Name</Label>
              <Input
                id="goal-name"
                value={goalName}
                onChange={(e) => setGoalName(e.target.value)}
                placeholder="e.g., New Laptop, Vacation, Emergency Fund"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="target-amount">Target Amount</Label>
              <Input
                id="target-amount"
                type="number"
                step="0.01"
                min="0"
                value={targetAmount}
                onChange={(e) => setTargetAmount(e.target.value)}
                placeholder="Enter amount"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="current-amount">Current Amount (Optional)</Label>
              <Input
                id="current-amount"
                type="number"
                step="0.01"
                min="0"
                value={currentAmount}
                onChange={(e) => setCurrentAmount(e.target.value)}
                placeholder="0.00"
              />
            </div>
            <div className="grid gap-2">
              <Label>Deadline (Optional)</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {deadline ? format(deadline, "PPP") : "Select a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={deadline}
                    onSelect={setDeadline}
                    initialFocus
                    disabled={(date) => date < new Date()}
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddGoal}>Add Goal</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Goal Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Savings Goal</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-goal-name">Goal Name</Label>
              <Input
                id="edit-goal-name"
                value={goalName}
                onChange={(e) => setGoalName(e.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-target-amount">Target Amount</Label>
              <Input
                id="edit-target-amount"
                type="number"
                step="0.01"
                min="0"
                value={targetAmount}
                onChange={(e) => setTargetAmount(e.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-current-amount">Current Amount</Label>
              <Input
                id="edit-current-amount"
                type="number"
                step="0.01"
                min="0"
                value={currentAmount}
                onChange={(e) => setCurrentAmount(e.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label>Deadline (Optional)</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {deadline ? format(deadline, "PPP") : "Select a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={deadline}
                    onSelect={setDeadline}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdateGoal}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Goal Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Savings Goal</DialogTitle>
          </DialogHeader>
          <p>
            Are you sure you want to delete the savings goal "{currentGoal?.name}"? This action cannot be undone.
          </p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteGoal}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Savings;
