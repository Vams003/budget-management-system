import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { CalendarIcon, Pencil, Trash2, Filter, ArrowUpDown } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { Transaction, Category } from "@/types/database";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useCurrency } from "@/hooks/use-currency";

const Transactions = () => {
  const { user } = useAuth();
  const { formatCurrency } = useCurrency();
  
  const [startDate, setStartDate] = useState<Date | undefined>(undefined);
  const [endDate, setEndDate] = useState<Date | undefined>(undefined);
  const [categoryFilter, setCategoryFilter] = useState<string | undefined>(undefined);
  const [amountFilter, setAmountFilter] = useState<number | undefined>(undefined);
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const [sortField, setSortField] = useState<string>("transaction_date");
  
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [currentTransaction, setCurrentTransaction] = useState<Transaction | null>(null);
  const [editDate, setEditDate] = useState<Date | undefined>(undefined);
  const [editAmount, setEditAmount] = useState<string>("");
  const [editDescription, setEditDescription] = useState<string>("");
  const [editCategoryId, setEditCategoryId] = useState<string>("");
  const [editIsExpense, setEditIsExpense] = useState<boolean>(true);

  const { data: categories } = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("categories")
        .select("*")
        .order("name");

      if (error) throw error;
      return data as Category[];
    },
  });

  const {
    data: transactions,
    isLoading,
    refetch,
  } = useQuery({
    queryKey: ["transactions", startDate, endDate, categoryFilter, amountFilter, sortField, sortDirection],
    queryFn: async () => {
      let query = supabase
        .from("transactions")
        .select(`
          *,
          categories:category_id (name, color)
        `)
        .eq("user_id", user?.id);

      if (startDate) {
        query = query.gte("transaction_date", format(startDate, "yyyy-MM-dd"));
      }
      if (endDate) {
        query = query.lte("transaction_date", format(endDate, "yyyy-MM-dd"));
      }
      if (categoryFilter) {
        query = query.eq("category_id", categoryFilter);
      }
      if (amountFilter) {
        query = query.lte("amount", amountFilter);
      }

      query = query.order(sortField, { ascending: sortDirection === "asc" });

      const { data, error } = await query;

      if (error) throw error;

      return data.map((transaction: any) => ({
        ...transaction,
        category_name: transaction.categories?.name,
        category_color: transaction.categories?.color,
      })) as Transaction[];
    },
  });

  const handleEditTransaction = async () => {
    if (!currentTransaction || !editDate) return;

    try {
      const { error } = await supabase
        .from("transactions")
        .update({
          amount: parseFloat(editAmount),
          description: editDescription,
          transaction_date: format(editDate, "yyyy-MM-dd"),
          category_id: editCategoryId || null,
          is_expense: editIsExpense,
        })
        .eq("id", currentTransaction.id);

      if (error) throw error;

      toast({
        title: "Transaction updated",
        description: "The transaction has been updated successfully.",
      });
      
      setEditDialogOpen(false);
      refetch();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleDeleteTransaction = async () => {
    if (!currentTransaction) return;

    try {
      const { error } = await supabase
        .from("transactions")
        .delete()
        .eq("id", currentTransaction.id);

      if (error) throw error;

      toast({
        title: "Transaction deleted",
        description: "The transaction has been deleted successfully.",
      });
      
      setDeleteDialogOpen(false);
      refetch();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const setupEditTransaction = (transaction: Transaction) => {
    setCurrentTransaction(transaction);
    setEditAmount(transaction.amount.toString());
    setEditDescription(transaction.description || "");
    setEditDate(transaction.transaction_date ? new Date(transaction.transaction_date) : undefined);
    setEditCategoryId(transaction.category_id || "");
    setEditIsExpense(transaction.is_expense);
    setEditDialogOpen(true);
  };

  const setupDeleteTransaction = (transaction: Transaction) => {
    setCurrentTransaction(transaction);
    setDeleteDialogOpen(true);
  };

  const formatCurrencyAmount = (amount: number) => {
    return formatCurrency(amount);
  };

  const toggleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  const resetFilters = () => {
    setStartDate(undefined);
    setEndDate(undefined);
    setCategoryFilter(undefined);
    setAmountFilter(undefined);
    setSortDirection("desc");
    setSortField("transaction_date");
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Transactions</h1>
      </div>

      <div className="flex flex-wrap gap-2 bg-muted/40 p-3 rounded-lg">
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" className="flex items-center gap-2">
              <CalendarIcon className="h-4 w-4" />
              <span>
                {startDate && endDate
                  ? `${format(startDate, "MMM d, yyyy")} - ${format(endDate, "MMM d, yyyy")}`
                  : startDate
                  ? `From ${format(startDate, "MMM d, yyyy")}`
                  : endDate
                  ? `Until ${format(endDate, "MMM d, yyyy")}`
                  : "Filter by date"}
              </span>
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <div className="p-3 space-y-3">
              <h3 className="font-medium">Date Range</h3>
              <div className="grid gap-2">
                <div className="grid gap-1">
                  <Label htmlFor="start-date">Start Date</Label>
                  <Calendar
                    mode="single"
                    selected={startDate}
                    onSelect={setStartDate}
                    className="border rounded-md"
                  />
                </div>
                <div className="grid gap-1">
                  <Label htmlFor="end-date">End Date</Label>
                  <Calendar
                    mode="single"
                    selected={endDate}
                    onSelect={setEndDate}
                    className="border rounded-md"
                  />
                </div>
              </div>
            </div>
          </PopoverContent>
        </Popover>

        <Select value={categoryFilter || "all-categories"} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filter by category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all-categories">All Categories</SelectItem>
            {categories?.map((category) => (
              <SelectItem key={category.id} value={category.id}>
                {category.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <div className="flex items-center gap-2">
          <Input
            type="number"
            placeholder="Max amount"
            className="w-32"
            value={amountFilter || ""}
            onChange={(e) => setAmountFilter(e.target.value ? parseFloat(e.target.value) : undefined)}
          />
        </div>

        <Button variant="ghost" onClick={resetFilters}>
          Reset Filters
        </Button>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="cursor-pointer" onClick={() => toggleSort("transaction_date")}>
                <div className="flex items-center gap-1">
                  Date
                  {sortField === "transaction_date" && (
                    <ArrowUpDown className={cn("h-4 w-4", sortDirection === "asc" ? "rotate-180" : "")} />
                  )}
                </div>
              </TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Description</TableHead>
              <TableHead className="cursor-pointer" onClick={() => toggleSort("amount")}>
                <div className="flex items-center gap-1">
                  Amount
                  {sortField === "amount" && (
                    <ArrowUpDown className={cn("h-4 w-4", sortDirection === "asc" ? "rotate-180" : "")} />
                  )}
                </div>
              </TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8">
                  Loading transactions...
                </TableCell>
              </TableRow>
            ) : !transactions || transactions.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8">
                  No transactions found.
                </TableCell>
              </TableRow>
            ) : (
              transactions.map((transaction) => (
                <TableRow key={transaction.id}>
                  <TableCell>
                    {transaction.transaction_date && format(new Date(transaction.transaction_date), "MMM d, yyyy")}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <div
                        className="h-3 w-3 rounded-full"
                        style={{ backgroundColor: transaction.category_color || "#ccc" }}
                      />
                      <span>{transaction.category_name || "Uncategorized"}</span>
                    </div>
                  </TableCell>
                  <TableCell>{transaction.description || "-"}</TableCell>
                  <TableCell
                    className={cn(
                      "font-medium",
                      transaction.is_expense ? "text-destructive" : "text-green-600"
                    )}
                  >
                    {transaction.is_expense ? "-" : "+"}
                    {formatCurrencyAmount(transaction.amount)}
                  </TableCell>
                  <TableCell>
                    <span
                      className={cn(
                        "px-2 py-1 rounded-full text-xs font-medium",
                        transaction.is_expense
                          ? "bg-destructive/20 text-destructive"
                          : "bg-green-100 text-green-800"
                      )}
                    >
                      {transaction.is_expense ? "Expense" : "Income"}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setupEditTransaction(transaction)}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setupDeleteTransaction(transaction)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Transaction</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-type">Type</Label>
              <Select
                value={editIsExpense ? "expense" : "income"}
                onValueChange={(value) => setEditIsExpense(value === "expense")}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="expense">Expense</SelectItem>
                  <SelectItem value="income">Income</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-amount">Amount</Label>
              <Input
                id="edit-amount"
                type="number"
                step="0.01"
                value={editAmount}
                onChange={(e) => setEditAmount(e.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-description">Description</Label>
              <Input
                id="edit-description"
                value={editDescription}
                onChange={(e) => setEditDescription(e.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-category">Category</Label>
              <Select value={editCategoryId || "uncategorized"} onValueChange={setEditCategoryId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="uncategorized">Uncategorized</SelectItem>
                  {categories?.filter(c => c.is_expense === editIsExpense).map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-date">Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {editDate ? format(editDate, "PPP") : "Select a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={editDate}
                    onSelect={setEditDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleEditTransaction}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Transaction</DialogTitle>
          </DialogHeader>
          <p>
            Are you sure you want to delete this transaction? This action cannot be undone.
          </p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteTransaction}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Transactions;
