
import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { toast } from "@/hooks/use-toast";
import { Category, Transaction } from "@/types/database";
import { useCurrency } from "@/hooks/use-currency";
import { CurrencyDisplay } from "@/components/ui/currency-display";
import { Budget as BudgetType } from "@/types/database";
import BudgetOverview from "@/components/budget/BudgetOverview";
import BudgetCategoryCard from "@/components/budget/BudgetCategoryCard";
import BudgetForm from "@/components/budget/BudgetForm";

const Budget = () => {
  const { user } = useAuth();
  const { formatCurrency } = useCurrency();
  const [showBudgetDialog, setShowBudgetDialog] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [budgetAmount, setBudgetAmount] = useState<string>("");
  const currentDate = new Date();
  const currentMonth = currentDate.getMonth() + 1;
  const currentYear = currentDate.getFullYear();

  const { data: categories } = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("categories")
        .select("*")
        .eq("is_expense", true)
        .order("name");

      if (error) throw error;
      return data as Category[];
    },
  });

  const {
    data: budgets,
    isLoading: isLoadingBudgets,
    refetch: refetchBudgets,
  } = useQuery({
    queryKey: ["budgets", currentMonth, currentYear],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("budgets")
        .select("*")
        .eq("user_id", user?.id)
        .eq("month", currentMonth)
        .eq("year", currentYear);

      if (error) throw error;
      return data as BudgetType[];
    },
  });

  const { data: transactions } = useQuery({
    queryKey: ["transactions", currentMonth, currentYear],
    queryFn: async () => {
      const startDate = `${currentYear}-${currentMonth.toString().padStart(2, "0")}-01`;
      const nextMonth = currentMonth === 12 ? 1 : currentMonth + 1;
      const nextYear = currentMonth === 12 ? currentYear + 1 : currentYear;
      const endDate = `${nextYear}-${nextMonth.toString().padStart(2, "0")}-01`;

      const { data, error } = await supabase
        .from("transactions")
        .select(`
          *,
          categories:category_id (id, name, color)
        `)
        .eq("user_id", user?.id)
        .eq("is_expense", true)
        .gte("transaction_date", startDate)
        .lt("transaction_date", endDate);

      if (error) throw error;
      
      return data.map((transaction: any) => ({
        ...transaction,
        category_name: transaction.categories?.name,
        category_color: transaction.categories?.color,
        category_id: transaction.categories?.id,
      })) as Transaction[];
    },
  });

  const calculateBudgetUsage = (categoryId: string) => {
    if (!transactions) return { spent: 0, percentage: 0 };

    const categoryTransactions = transactions.filter(
      (t) => t.category_id === categoryId
    );
    const spent = categoryTransactions.reduce((sum, t) => sum + t.amount, 0);
    
    const budget = budgets?.find((b) => b.id.includes(categoryId));
    const budgetAmount = budget?.amount || 0;
    
    const percentage = budgetAmount > 0 ? (spent / budgetAmount) * 100 : 0;
    
    return { spent, percentage, budgetAmount };
  };

  const handleSetBudget = async () => {
    if (!selectedCategory || !budgetAmount) return;

    const amount = parseFloat(budgetAmount);
    if (isNaN(amount) || amount <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid budget amount.",
        variant: "destructive",
      });
      return;
    }

    const existingBudget = budgets?.find(b => 
      b.id.includes(selectedCategory.id) && 
      b.month === currentMonth && 
      b.year === currentYear
    );

    try {
      if (existingBudget) {
        const { error } = await supabase
          .from("budgets")
          .update({ amount })
          .eq("id", existingBudget.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("budgets")
          .insert({
            user_id: user?.id,
            month: currentMonth,
            year: currentYear,
            amount,
            id: `${user?.id}_${selectedCategory.id}_${currentMonth}_${currentYear}`,
          });

        if (error) throw error;
      }

      toast({
        title: "Budget set",
        description: `Budget for ${selectedCategory.name} has been set to ${formatCurrency(amount)}.`,
      });
      
      setShowBudgetDialog(false);
      setBudgetAmount("");
      refetchBudgets();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const chartData = categories?.map((category) => {
    const { spent, budgetAmount } = calculateBudgetUsage(category.id);
    return {
      name: category.name,
      budget: budgetAmount,
      spent: spent,
    };
  });

  const getBudgetStatus = (percentage: number) => {
    if (percentage > 100) return { isOverBudget: true, isNearLimit: false };
    if (percentage > 80) return { isOverBudget: false, isNearLimit: true };
    return { isOverBudget: false, isNearLimit: false };
  };

  const generateSuggestion = (categoryName: string, percentage: number) => {
    if (percentage < 50) return null;

    const suggestions: Record<string, string[]> = {
      Food: [
        "Consider meal prepping to save on daily food expenses.",
        "Try cooking at home more often to reduce restaurant spending.",
        "Look for student discounts at local restaurants and grocery stores."
      ],
      Entertainment: [
        "Check for free campus events instead of paid entertainment.",
        "Consider sharing subscription services with roommates.",
        "Look for student discounts on movies and events."
      ],
      Transportation: [
        "Consider using public transportation or carpooling.",
        "Try walking or biking for short distances.",
        "Check if your school offers discounted transit passes."
      ],
      Shopping: [
        "Make a shopping list and stick to it to avoid impulse purchases.",
        "Look for second-hand items or student discounts.",
        "Wait 24 hours before making non-essential purchases."
      ],
      default: [
        "Try setting aside small amounts regularly to stay within budget.",
        "Look for student discounts to reduce expenses.",
        "Track your spending more closely to identify savings opportunities."
      ]
    };

    const categorySuggestions = suggestions[categoryName] || suggestions.default;
    const randomIndex = Math.floor(Math.random() * categorySuggestions.length);
    return categorySuggestions[randomIndex];
  };

  const handleCategoryBudgetClick = (category: Category) => {
    const { budgetAmount } = calculateBudgetUsage(category.id);
    setSelectedCategory(category);
    setBudgetAmount(budgetAmount.toString());
    setShowBudgetDialog(true);
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Budget</h1>
        <div className="text-sm text-muted-foreground">
          {new Date().toLocaleDateString("en-US", { month: "long", year: "numeric" })}
        </div>
      </div>

      {chartData && <BudgetOverview chartData={chartData} formatCurrency={formatCurrency} />}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {categories?.map((category) => {
          const { spent, percentage, budgetAmount } = calculateBudgetUsage(category.id);
          const { isOverBudget, isNearLimit } = getBudgetStatus(percentage);
          const suggestion = generateSuggestion(category.name, percentage);

          return (
            <BudgetCategoryCard
              key={category.id}
              category={category}
              spent={spent}
              percentage={percentage}
              budgetAmount={budgetAmount}
              isOverBudget={isOverBudget}
              isNearLimit={isNearLimit}
              suggestion={suggestion}
              formatCurrency={formatCurrency}
              onSetBudget={handleCategoryBudgetClick}
            />
          );
        })}
      </div>

      <BudgetForm
        open={showBudgetDialog}
        onOpenChange={setShowBudgetDialog}
        selectedCategory={selectedCategory}
        budgetAmount={budgetAmount}
        onBudgetAmountChange={setBudgetAmount}
        onSaveBudget={handleSetBudget}
      />
    </div>
  );
};

export default Budget;
