import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from "recharts";
import { useQuery } from "@tanstack/react-query";
import { DollarSign, TrendingUp, TrendingDown, Target } from "lucide-react";
import { cn } from "@/lib/utils";
import { Transaction, Budget, SavingsGoal, CategorySummary, MonthlyData } from "@/types/database";
import { CurrencyDisplay } from "@/components/ui/currency-display";
import { useCurrency } from "@/hooks/use-currency";

const getCurrentMonthYear = () => {
  const now = new Date();
  return {
    month: now.getMonth() + 1, // JavaScript months are 0-indexed
    year: now.getFullYear(),
  };
};

const monthNames = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

export default function Dashboard() {
  const { user } = useAuth();
  const { month, year } = getCurrentMonthYear();
  const [monthlyBudget, setMonthlyBudget] = useState<Budget | null>(null);
  const { formatCurrency } = useCurrency();
  
  // Fetch recent transactions
  const { data: recentTransactions = [] } = useQuery({
    queryKey: ['recentTransactions', user?.id],
    queryFn: async () => {
      if (!user) return [];
      
      const { data, error } = await supabase
        .from('transactions')
        .select(`
          *,
          categories:category_id (name, color)
        `)
        .eq('user_id', user.id)
        .order('transaction_date', { ascending: false })
        .limit(10);
      
      if (error) throw error;
      
      return data.map((transaction: any) => ({
        ...transaction,
        category_name: transaction.categories?.name,
        category_color: transaction.categories?.color,
      })) as Transaction[];
    },
  });

  // Fetch monthly budget
  useEffect(() => {
    const fetchBudget = async () => {
      if (user) {
        const { data, error } = await supabase
          .from('budgets')
          .select('*')
          .eq('user_id', user.id)
          .eq('month', month)
          .eq('year', year)
          .single();
        
        if (!error && data) {
          setMonthlyBudget(data as Budget);
        }
      }
    };
    
    fetchBudget();
  }, [user, month, year]);

  // Fetch savings goals
  const { data: savingsGoals = [] } = useQuery({
    queryKey: ['savingsGoals', user?.id],
    queryFn: async () => {
      if (!user) return [];
      
      const { data, error } = await supabase
        .from('savings_goals')
        .select('*')
        .eq('user_id', user.id);
      
      if (error) throw error;
      return data as SavingsGoal[];
    },
  });

  // Calculate total income and expenses for current month
  const { data: monthlySummary = { income: 0, expenses: 0 } } = useQuery({
    queryKey: ['monthlySummary', user?.id, month, year],
    queryFn: async () => {
      if (!user) return { income: 0, expenses: 0 };
      
      const startDate = `${year}-${month.toString().padStart(2, '0')}-01`;
      const lastDay = new Date(year, month, 0).getDate();
      const endDate = `${year}-${month.toString().padStart(2, '0')}-${lastDay}`;
      
      const { data, error } = await supabase
        .from('transactions')
        .select('*')
        .eq('user_id', user.id)
        .gte('transaction_date', startDate)
        .lte('transaction_date', endDate);
      
      if (error) throw error;
      
      const transactions = data as Transaction[];
      
      const income = transactions
        .filter(t => !t.is_expense)
        .reduce((sum, t) => sum + t.amount, 0);
      
      const expenses = transactions
        .filter(t => t.is_expense)
        .reduce((sum, t) => sum + t.amount, 0);
      
      return { income, expenses };
    },
  });

  // Prepare category data for pie chart
  const { data: categoryData = [] } = useQuery({
    queryKey: ['categoryData', user?.id, month, year],
    queryFn: async () => {
      if (!user) return [];
      
      const startDate = `${year}-${month.toString().padStart(2, '0')}-01`;
      const lastDay = new Date(year, month, 0).getDate();
      const endDate = `${year}-${month.toString().padStart(2, '0')}-${lastDay}`;
      
      const { data, error } = await supabase
        .from('transactions')
        .select(`
          amount, is_expense,
          categories:category_id (id, name, color)
        `)
        .eq('user_id', user.id)
        .eq('is_expense', true)
        .gte('transaction_date', startDate)
        .lte('transaction_date', endDate);
      
      if (error) throw error;
      
      const categorySummary: { [key: string]: CategorySummary } = {};
      
      (data as any[]).forEach(transaction => {
        const categoryId = transaction.categories?.id;
        if (categoryId) {
          if (!categorySummary[categoryId]) {
            categorySummary[categoryId] = {
              name: transaction.categories.name,
              value: 0,
              color: transaction.categories.color || '#888888',
            };
          }
          categorySummary[categoryId].value += transaction.amount;
        }
      });
      
      return Object.values(categorySummary);
    },
  });

  // Prepare monthly data for bar chart
  const { data: monthlyData = [] } = useQuery({
    queryKey: ['monthlyData', user?.id, year],
    queryFn: async () => {
      if (!user) return [];
      
      const startDate = `${year}-01-01`;
      const endDate = `${year}-12-31`;
      
      const { data, error } = await supabase
        .from('transactions')
        .select('amount, is_expense, transaction_date')
        .eq('user_id', user.id)
        .gte('transaction_date', startDate)
        .lte('transaction_date', endDate);
      
      if (error) throw error;
      
      const transactions = data as Transaction[];
      const monthlyData = Array(12).fill(0).map((_, i) => ({
        name: monthNames[i].substring(0, 3),
        income: 0,
        expenses: 0,
      }));
      
      transactions.forEach(transaction => {
        const date = new Date(transaction.transaction_date);
        const monthIndex = date.getMonth();
        
        if (transaction.is_expense) {
          monthlyData[monthIndex].expenses += transaction.amount;
        } else {
          monthlyData[monthIndex].income += transaction.amount;
        }
      });
      
      return monthlyData;
    },
  });

  const totalIncome = monthlySummary.income;
  const totalExpenses = monthlySummary.expenses;
  const balance = totalIncome - totalExpenses;
  const budgetProgress = monthlyBudget ? (totalExpenses / monthlyBudget.amount) * 100 : 0;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
      <p className="text-muted-foreground">
        Welcome to your financial dashboard for {monthNames[month - 1]} {year}
      </p>

      {/* Key Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {/* Income Card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Income</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              <CurrencyDisplay amount={totalIncome} />
            </div>
            <p className="text-xs text-muted-foreground">
              This month's earnings
            </p>
          </CardContent>
        </Card>

        {/* Expenses Card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Expenses</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              <CurrencyDisplay amount={totalExpenses} />
            </div>
            <p className="text-xs text-muted-foreground">
              This month's spending
            </p>
          </CardContent>
        </Card>

        {/* Balance Card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Balance</CardTitle>
            <DollarSign className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className={cn(
              "text-2xl font-bold",
              balance < 0 ? "text-red-500" : "text-green-500"
            )}>
              <CurrencyDisplay amount={balance} />
            </div>
            <p className="text-xs text-muted-foreground">
              Income - Expenses
            </p>
          </CardContent>
        </Card>

        {/* Budget Card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Budget</CardTitle>
            <Target className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {monthlyBudget 
                ? <><CurrencyDisplay amount={totalExpenses} /> / <CurrencyDisplay amount={monthlyBudget.amount} /></>
                : "No budget set"}
            </div>
            {monthlyBudget && (
              <div className="mt-2 h-2 w-full bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className={cn(
                    "h-full",
                    budgetProgress > 100 ? "bg-red-500" : "bg-green-500"
                  )}
                  style={{ width: `${Math.min(budgetProgress, 100)}%` }}
                />
              </div>
            )}
            <p className="text-xs text-muted-foreground mt-1">
              {monthlyBudget
                ? `${budgetProgress.toFixed(0)}% of monthly budget`
                : "Set a budget in the Budget section"}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid gap-4 md:grid-cols-2">
        {/* Expense by Category */}
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Expenses by Category</CardTitle>
            <CardDescription>
              This month's spending breakdown
            </CardDescription>
          </CardHeader>
          <CardContent className="h-80">
            {categoryData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-full text-muted-foreground">
                No expense data available
              </div>
            )}
          </CardContent>
        </Card>

        {/* Monthly Income vs Expense */}
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Income vs Expenses</CardTitle>
            <CardDescription>
              Year-to-date monthly comparison
            </CardDescription>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyData}>
                <XAxis dataKey="name" />
                <YAxis tickFormatter={(value) => formatCurrency(Number(value)).split(' ')[0]} />
                <Tooltip 
                  formatter={(value) => formatCurrency(Number(value))}
                  labelFormatter={(label) => `Month: ${label}`}
                />
                <Legend />
                <Bar dataKey="income" name="Income" fill="#4CAF50" />
                <Bar dataKey="expenses" name="Expenses" fill="#FF5722" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Recent Transactions */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Transactions</CardTitle>
          <CardDescription>
            Your latest 10 financial activities
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {recentTransactions.length > 0 ? (
              recentTransactions.map((transaction: Transaction) => (
                <div key={transaction.id} className="flex items-center justify-between p-3 border rounded-md">
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: transaction.category_color || '#888888' }}
                    />
                    <div>
                      <p className="font-medium">{transaction.description || transaction.category_name || 'Uncategorized'}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(transaction.transaction_date).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <span className={cn(
                    "font-medium",
                    transaction.is_expense ? "text-red-500" : "text-green-500"
                  )}>
                    {transaction.is_expense ? '-' : '+'}<CurrencyDisplay amount={transaction.amount} />
                  </span>
                </div>
              ))
            ) : (
              <p className="text-center py-4 text-muted-foreground">No recent transactions</p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Savings Goals */}
      {savingsGoals.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Savings Goals</CardTitle>
            <CardDescription>
              Track your progress towards financial goals
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {savingsGoals.map((goal: SavingsGoal) => {
                const progress = (goal.current_amount / goal.target_amount) * 100;
                return (
                  <div key={goal.id} className="space-y-1">
                    <div className="flex justify-between items-center">
                      <p className="font-medium">{goal.name}</p>
                      <p className="text-sm">
                        <CurrencyDisplay amount={goal.current_amount} /> / <CurrencyDisplay amount={goal.target_amount} />
                      </p>
                    </div>
                    <div className="h-2 w-full bg-gray-200 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-blue-500"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>{progress.toFixed(0)}% complete</span>
                      {goal.deadline && (
                        <span>Due by {new Date(goal.deadline).toLocaleDateString()}</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
