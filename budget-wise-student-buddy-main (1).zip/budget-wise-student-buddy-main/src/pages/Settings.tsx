
import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { Transaction, Budget } from "@/types/database";

// Import the refactored components
import ProfileSettings from "@/components/settings/ProfileSettings";
import AppearanceSettings from "@/components/settings/AppearanceSettings";
import ExportData from "@/components/settings/ExportData";
import CurrencySettings from "@/components/settings/CurrencySettings";
import SecondaryCurrencySettings from "@/components/settings/SecondaryCurrencySettings";

export default function Settings() {
  const { user } = useAuth();
  const [fullName, setFullName] = useState("");
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Get transactions for export
  const { data: transactions } = useQuery({
    queryKey: ["transactions-export", user?.id],
    queryFn: async () => {
      if (!user) return [];
      
      const { data, error } = await supabase
        .from("transactions")
        .select(`
          *,
          categories:category_id (name)
        `)
        .eq("user_id", user.id)
        .order("transaction_date", { ascending: false });
      
      if (error) throw error;
      
      return data.map((transaction: any) => ({
        ...transaction,
        category_name: transaction.categories?.name || "Uncategorized",
      })) as Transaction[];
    },
  });

  // Get budgets for export
  const { data: budgets } = useQuery({
    queryKey: ["budgets-export", user?.id],
    queryFn: async () => {
      if (!user) return [];
      
      const { data, error } = await supabase
        .from("budgets")
        .select("*")
        .eq("user_id", user.id);
      
      if (error) throw error;
      return data as Budget[];
    },
  });

  // Get user profile
  useEffect(() => {
    const fetchProfile = async () => {
      if (user) {
        const { data, error } = await supabase
          .from("profiles")
          .select("full_name")
          .eq("id", user.id)
          .single();
        
        if (!error && data) {
          setFullName(data.full_name || "");
        }
      }
    };
    
    fetchProfile();

    // Check for dark mode preference in localStorage
    const darkModePreference = localStorage.getItem("darkMode") === "true";
    setIsDarkMode(darkModePreference);
    
    if (darkModePreference) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [user]);

  return (
    <div className="container mx-auto py-6 space-y-6">
      <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
      
      {/* Profile Settings */}
      <ProfileSettings 
        user={user}
        fullName={fullName}
        setFullName={setFullName}
      />
      
      {/* Currency Settings */}
      <CurrencySettings />
      
      {/* Secondary Currency Settings */}
      <SecondaryCurrencySettings />
      
      {/* Appearance Settings */}
      <AppearanceSettings 
        isDarkMode={isDarkMode}
        setIsDarkMode={setIsDarkMode}
      />
      
      {/* Export Data */}
      <ExportData 
        transactions={transactions}
        budgets={budgets}
      />
    </div>
  );
}
