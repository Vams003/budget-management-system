
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  ArrowRight, 
  BarChart, 
  Wallet, 
  Repeat, 
  PiggyBank, 
  TrendingUp, 
  User 
} from "lucide-react";

const Index = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Trigger animation after component mount
    setIsVisible(true);
    
    // If user is already logged in, redirect to dashboard
    if (user) {
      navigate("/dashboard");
    }
  }, [user, navigate]);

  const handleAuthRedirect = (route: string) => {
    navigate(route);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
      {/* Hero Section */}
      <section className="container px-4 py-20 mx-auto text-center">
        <div className={`transition-all duration-1000 transform ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
          <h1 className="text-4xl font-bold tracking-tight text-primary sm:text-6xl mb-6">
            BudgetWise
          </h1>
          <p className="max-w-2xl mx-auto text-xl text-gray-600 dark:text-gray-300 mb-10">
            Your personal student budget management solution. Take control of your finances and plan for a better future.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button 
              onClick={() => handleAuthRedirect("/auth")} 
              size="lg" 
              className="animate-bounce"
            >
              Get Started <ArrowRight className="ml-2" />
            </Button>
            <Button 
              onClick={() => handleAuthRedirect("/auth")} 
              variant="outline"
              size="lg"
              className="hover:scale-105 transition-transform"
            >
              Login to Your Account
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container px-4 py-16 mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12">
          Features That Make Budgeting Easy
        </h2>
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          <FeatureCard 
            icon={<Wallet className="h-10 w-10 text-primary" />}
            title="Transaction Tracking"
            description="Record and categorize all your expenses and income in one place."
            delay={100}
            isVisible={isVisible}
          />
          <FeatureCard 
            icon={<BarChart className="h-10 w-10 text-primary" />}
            title="Budget Planning"
            description="Create monthly budgets for different categories and track your spending."
            delay={200}
            isVisible={isVisible}
          />
          <FeatureCard 
            icon={<Repeat className="h-10 w-10 text-primary" />}
            title="Recurring Transactions"
            description="Set up and manage recurring expenses like subscriptions and bills."
            delay={300}
            isVisible={isVisible}
          />
          <FeatureCard 
            icon={<PiggyBank className="h-10 w-10 text-primary" />}
            title="Savings Goals"
            description="Plan and track your progress towards financial goals."
            delay={400}
            isVisible={isVisible}
          />
          <FeatureCard 
            icon={<TrendingUp className="h-10 w-10 text-primary" />}
            title="Financial Insights"
            description="Get visualizations and reports on your spending habits."
            delay={500}
            isVisible={isVisible}
          />
          <FeatureCard 
            icon={<User className="h-10 w-10 text-primary" />}
            title="Personalized Experience"
            description="Customize your dashboard and preferences for your unique needs."
            delay={600}
            isVisible={isVisible}
          />
        </div>
      </section>

      {/* CTA Section */}
      <section className="container px-4 py-16 mx-auto text-center">
        <div className={`bg-primary/10 rounded-2xl p-10 transition-all duration-1000 transform ${isVisible ? 'scale-100 opacity-100' : 'scale-95 opacity-0'}`}>
          <h2 className="text-3xl font-bold mb-4">Ready to Take Control of Your Finances?</h2>
          <p className="max-w-2xl mx-auto text-lg text-gray-600 dark:text-gray-300 mb-8">
            Join thousands of students who are managing their finances smarter with BudgetWise.
          </p>
          <Button 
            onClick={() => handleAuthRedirect("/auth")} 
            size="lg" 
            className="hover:animate-pulse"
          >
            Sign Up Now
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="container px-4 py-8 mx-auto text-center text-gray-500 dark:text-gray-400">
        <p>© {new Date().getFullYear()} BudgetWise. All rights reserved.</p>
      </footer>
    </div>
  );
};

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  delay: number;
  isVisible: boolean;
}

const FeatureCard = ({ icon, title, description, delay, isVisible }: FeatureCardProps) => {
  return (
    <Card className={`transition-all duration-1000 delay-${delay} transform hover:scale-105 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
      <CardHeader className="flex flex-row items-center gap-4">
        {icon}
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <CardDescription className="text-base">{description}</CardDescription>
      </CardContent>
    </Card>
  );
};

export default Index;
