
import { supabase } from "@/integrations/supabase/client";
import {
  GetExchangeRatesParams,
  CreateRecurringTransactionParams,
  UpdateRecurringTransactionParams,
  DeleteRecurringTransactionParams,
  GetRecurringTransactionsParams,
  FrequencyType
} from "@/types/supabase-rpc";

type RPCFunctionName = 
  | "get_exchange_rates"
  | "create_recurring_transaction"
  | "update_recurring_transaction"
  | "delete_recurring_transaction"
  | "get_recurring_transactions";

type RPCParamMap = {
  "get_exchange_rates": GetExchangeRatesParams;
  "create_recurring_transaction": CreateRecurringTransactionParams;
  "update_recurring_transaction": UpdateRecurringTransactionParams;
  "delete_recurring_transaction": DeleteRecurringTransactionParams;
  "get_recurring_transactions": GetRecurringTransactionsParams;
}

/**
 * Helper function to call Supabase RPC functions with type safety
 * @param functionName The name of the RPC function to call
 * @param params The parameters to pass to the RPC function
 * @returns The result of the RPC call
 */
export async function callRPC<T extends RPCFunctionName>(
  functionName: T, 
  params: RPCParamMap[T]
) {
  // Create a single object to pass to the RPC function
  const paramObject = {
    transaction_data: params
  };
  
  return supabase.rpc(functionName, paramObject);
}
