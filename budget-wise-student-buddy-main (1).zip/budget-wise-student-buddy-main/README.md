
# 📊 Student Budget Management System

A modern web app that helps students manage their finances with budgeting, expense tracking, savings goals, and AI tips.

## 🔧 Built With
- React + Vite + TailwindCSS
- Supabase (Auth, DB, RLS)
- TypeScript
- React Query
- CSV / PDF Export
- AI Budget Suggestions
- ShadCN UI Components

## 🔐 Features
- ✅ Login/Signup (with secure RLS)
- ✅ Dashboard: Balance, expenses, tips
- ✅ Budget per category
- ✅ Savings tracker
- ✅ Mobile responsive
- ✅ Dark mode
- ✅ Export (CSV/PDF)
- ✅ AI suggestions when overspending
- ✅ Data-secure via RLS

## 🚀 Getting Started

### Prerequisites
- Node.js (v18 or higher)
- npm or bun

### Installation

1. Clone the repository
```bash
git clone <repository-url>
cd student-budget-management
```

2. Install dependencies
```bash
npm install
# or
bun install
```

3. Start the development server
```bash
npm run dev
# or
bun run dev
```

4. Open your browser and navigate to `http://localhost:5173`

## 📱 Application Structure

The application is structured into several key areas:

- **Authentication** - Secure login and signup with Supabase Auth
- **Dashboard** - Overview of financial status
- **Transactions** - Record and manage income and expenses
- **Budget** - Set and track category-based budgets
- **Savings** - Set and track savings goals
- **Settings** - User preferences and data export

## 🔒 Security

The application implements Row Level Security (RLS) in Supabase to ensure that:
- Users can only access their own data
- Data is securely stored in the database
- Authentication is handled securely

## 📈 Future Enhancements

Potential future improvements:
- Multi-language support
- Unit and integration testing
- Recurring transactions
- Email notifications for budget alerts
- Peer comparison graphs

## 🧠 Contributing

Contributions are welcome! Feel free to open issues or submit pull requests.

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- ShadCN UI for the beautiful component library
- Supabase for the backend infrastructure
- The React and TypeScript communities
