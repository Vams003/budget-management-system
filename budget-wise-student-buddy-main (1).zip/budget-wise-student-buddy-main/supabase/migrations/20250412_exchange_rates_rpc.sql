
-- Create RPC functions for exchange rates
CREATE OR REPLACE FUNCTION public.get_exchange_rates()
RETURNS JSON
LANGUAGE SQL
SECURITY DEFINER
AS $$
  SELECT rates::json FROM public.exchange_rates WHERE id = 1;
$$;

-- Create RPC functions to handle recurring transactions
-- Get recurring transactions function
CREATE OR REPLACE FUNCTION public.get_recurring_transactions(user_id_param UUID)
RETURNS SETOF JSON
LANGUAGE SQL
SECURITY DEFINER
AS $$
  SELECT json_build_object(
    'id', rt.id,
    'user_id', rt.user_id,
    'amount', rt.amount,
    'description', rt.description,
    'category_id', rt.category_id,
    'is_expense', rt.is_expense,
    'frequency', rt.frequency,
    'start_date', rt.start_date,
    'end_date', rt.end_date,
    'last_generated_date', rt.last_generated_date,
    'created_at', rt.created_at,
    'updated_at', rt.updated_at,
    'category_name', c.name,
    'category_color', c.color
  )
  FROM public.recurring_transactions rt
  LEFT JOIN public.categories c ON rt.category_id = c.id
  WHERE rt.user_id = user_id_param
  ORDER BY rt.created_at DESC;
$$;

-- Create recurring transaction function
CREATE OR REPLACE FUNCTION public.create_recurring_transaction(
  user_id_param UUID,
  amount_param NUMERIC,
  description_param TEXT,
  category_id_param UUID,
  is_expense_param BOOLEAN,
  frequency_param TEXT,
  start_date_param DATE,
  end_date_param DATE
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  new_id UUID;
BEGIN
  INSERT INTO public.recurring_transactions (
    user_id,
    amount,
    description,
    category_id,
    is_expense,
    frequency,
    start_date,
    end_date
  ) VALUES (
    user_id_param,
    amount_param,
    description_param,
    category_id_param,
    is_expense_param,
    frequency_param,
    start_date_param,
    end_date_param
  )
  RETURNING id INTO new_id;
  
  RETURN new_id;
END;
$$;

-- Update recurring transaction function
CREATE OR REPLACE FUNCTION public.update_recurring_transaction(
  transaction_id_param UUID,
  user_id_param UUID,
  amount_param NUMERIC,
  description_param TEXT,
  category_id_param UUID,
  is_expense_param BOOLEAN,
  frequency_param TEXT,
  start_date_param DATE,
  end_date_param DATE
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.recurring_transactions
  SET
    amount = amount_param,
    description = description_param,
    category_id = category_id_param,
    is_expense = is_expense_param,
    frequency = frequency_param,
    start_date = start_date_param,
    end_date = end_date_param,
    updated_at = NOW()
  WHERE id = transaction_id_param AND user_id = user_id_param;
END;
$$;

-- Delete recurring transaction function
CREATE OR REPLACE FUNCTION public.delete_recurring_transaction(
  transaction_id_param UUID,
  user_id_param UUID
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  DELETE FROM public.recurring_transactions
  WHERE id = transaction_id_param AND user_id = user_id_param;
END;
$$;
