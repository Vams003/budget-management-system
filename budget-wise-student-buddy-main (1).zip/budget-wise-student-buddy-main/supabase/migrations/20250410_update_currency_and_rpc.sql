
-- Create a function to update user currency
CREATE OR REPLACE FUNCTION public.update_user_currency(
  user_id_param UUID,
  currency_code TEXT
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.profiles 
  SET currency = currency_code
  WHERE id = user_id_param;
END;
$$;

-- Create a function to create recurring transactions
CREATE OR REPLACE FUNCTION public.create_recurring_transaction(
  transaction_data JSONB
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  new_id UUID;
BEGIN
  INSERT INTO public.recurring_transactions (
    user_id,
    amount,
    description,
    category_id,
    is_expense,
    frequency,
    start_date,
    end_date
  ) VALUES (
    (transaction_data->>'user_id')::UUID,
    (transaction_data->>'amount')::NUMERIC,
    transaction_data->>'description',
    NULLIF(transaction_data->>'category_id', '')::UUID,
    (transaction_data->>'is_expense')::BOOLEAN,
    transaction_data->>'frequency',
    (transaction_data->>'start_date')::DATE,
    (transaction_data->>'end_date')::DATE
  )
  RETURNING id INTO new_id;
  
  RETURN new_id;
END;
$$;

-- Create a function to update recurring transactions
CREATE OR REPLACE FUNCTION public.update_recurring_transaction(
  transaction_id UUID,
  transaction_data JSONB
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.recurring_transactions
  SET
    amount = (transaction_data->>'amount')::NUMERIC,
    description = transaction_data->>'description',
    category_id = NULLIF(transaction_data->>'category_id', '')::UUID,
    is_expense = (transaction_data->>'is_expense')::BOOLEAN,
    frequency = transaction_data->>'frequency',
    start_date = (transaction_data->>'start_date')::DATE,
    end_date = (transaction_data->>'end_date')::DATE,
    updated_at = NOW()
  WHERE id = transaction_id AND user_id = (transaction_data->>'user_id')::UUID;
END;
$$;

-- Create a function to delete recurring transactions
CREATE OR REPLACE FUNCTION public.delete_recurring_transaction(
  transaction_id UUID
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  DELETE FROM public.recurring_transactions
  WHERE id = transaction_id;
END;
$$;

-- Create a function to get recurring transactions with categories
CREATE OR REPLACE FUNCTION public.get_recurring_transactions_with_categories(
  user_id_param UUID
)
RETURNS SETOF json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    json_build_object(
      'id', rt.id,
      'user_id', rt.user_id,
      'amount', rt.amount,
      'description', rt.description,
      'category_id', rt.category_id,
      'is_expense', rt.is_expense,
      'frequency', rt.frequency,
      'start_date', rt.start_date,
      'end_date', rt.end_date,
      'last_generated_date', rt.last_generated_date,
      'created_at', rt.created_at,
      'updated_at', rt.updated_at,
      'category_name', c.name,
      'category_color', c.color
    )
  FROM 
    public.recurring_transactions rt
  LEFT JOIN 
    public.categories c ON rt.category_id = c.id
  WHERE 
    rt.user_id = user_id_param
  ORDER BY 
    rt.created_at DESC;
END;
$$;
