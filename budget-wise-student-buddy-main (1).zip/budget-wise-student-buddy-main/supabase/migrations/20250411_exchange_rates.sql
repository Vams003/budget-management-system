
-- Create the exchange_rates table to store cached rates
CREATE TABLE IF NOT EXISTS public.exchange_rates (
  id INTEGER PRIMARY KEY,
  rates JSONB NOT NULL,
  last_updated TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create an RPC function to get exchange rates
CREATE OR REPLACE FUNCTION public.get_exchange_rates()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  rates_data JSONB;
  last_updated TIMESTAMP WITH TIME ZONE;
BEGIN
  -- Get the latest exchange rates from the cache
  SELECT er.rates, er.last_updated 
  INTO rates_data, last_updated
  FROM public.exchange_rates er
  WHERE er.id = 1;
  
  -- If we have recent rates (less than 24 hours old), use them
  IF rates_data IS NOT NULL AND last_updated > (now() - interval '24 hours') THEN
    RETURN rates_data;
  ELSE
    -- Otherwise, return empty object - client will trigger refresh
    RETURN '{}'::JSONB;
  END IF;
END;
$$;

-- Enable the pg_cron and pg_net extensions (needed for scheduled functions)
CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS pg_net;

-- Schedule the exchange rate update function to run daily
SELECT cron.schedule(
  'update-exchange-rates-daily',
  '0 0 * * *', -- Run at midnight every day
  $$
  SELECT net.http_post(
    url:='https://pfafcnfdgzmqwqvwmdpu.supabase.co/functions/v1/fetch-exchange-rates',
    headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBmYWZjbmZkZ3ptcXdxdndtZHB1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDQyMDc1ODUsImV4cCI6MjA1OTc4MzU4NX0.a0Xrx20MmsH14WfI399QfE3zCaoxuK61Xrg5pKCZyeI"}'::jsonb,
    body:='{}'::jsonb
  ) AS request_id;
  $$
);
