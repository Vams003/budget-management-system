
// Follow this setup guide to integrate the Deno runtime into your application:
// https://deno.com/deploy/docs/serve-function
import { serve } from "https://deno.land/std@0.131.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.7.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);
    
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    console.log(`Processing recurring transactions for date: ${today}`);

    // Get all recurring transactions that need processing
    const { data: recurringTransactions, error: fetchError } = await supabase
      .from("recurring_transactions")
      .select("*")
      .or(`last_generated_date.is.null,last_generated_date.lt.${today}`)
      .lt("start_date", today + "T23:59:59Z") // Ensure start date has passed
      .or(`end_date.is.null,end_date.gte.${today}`); // Ensure not past end date
    
    if (fetchError) {
      throw new Error(`Error fetching recurring transactions: ${fetchError.message}`);
    }

    console.log(`Found ${recurringTransactions?.length || 0} recurring transactions to process`);
    
    const processedTransactions = [];
    
    // Process each recurring transaction
    for (const recurring of recurringTransactions || []) {
      console.log(`Processing recurring transaction: ${recurring.id}`);
      
      let shouldGenerate = false;
      let nextDate = today;
      
      if (!recurring.last_generated_date) {
        // First time processing this recurring transaction
        shouldGenerate = true;
      } else {
        const lastDate = new Date(recurring.last_generated_date);
        const currentDate = new Date(today);
        
        switch (recurring.frequency) {
          case 'daily':
            // Should generate if at least 1 day has passed
            shouldGenerate = (currentDate.getTime() - lastDate.getTime()) >= (24 * 60 * 60 * 1000);
            break;
          case 'weekly':
            // Should generate if at least 7 days have passed
            shouldGenerate = (currentDate.getTime() - lastDate.getTime()) >= (7 * 24 * 60 * 60 * 1000);
            break;
          case 'monthly':
            // Should generate if we're in a new month compared to last generation
            shouldGenerate = 
              currentDate.getMonth() !== lastDate.getMonth() || 
              currentDate.getFullYear() !== lastDate.getFullYear();
            break;
          case 'yearly':
            // Should generate if we're in a new year compared to last generation
            shouldGenerate = currentDate.getFullYear() !== lastDate.getFullYear();
            break;
        }
      }
      
      if (shouldGenerate) {
        console.log(`Generating transaction for recurring ${recurring.id}`);
        
        // Insert the transaction
        const { error: insertError } = await supabase
          .from("transactions")
          .insert({
            user_id: recurring.user_id,
            category_id: recurring.category_id,
            amount: recurring.amount,
            description: recurring.description || `Recurring: ${recurring.frequency}`,
            is_expense: recurring.is_expense,
            transaction_date: today,
          });
        
        if (insertError) {
          console.error(`Error inserting transaction for recurring ${recurring.id}: ${insertError.message}`);
          continue;
        }
        
        // Update the last generated date
        const { error: updateError } = await supabase
          .from("recurring_transactions")
          .update({ last_generated_date: today })
          .eq("id", recurring.id);
        
        if (updateError) {
          console.error(`Error updating last_generated_date for recurring ${recurring.id}: ${updateError.message}`);
          continue;
        }
        
        processedTransactions.push(recurring.id);
      } else {
        console.log(`Skipping recurring transaction ${recurring.id} as it's not time to generate yet`);
      }
    }
    
    return new Response(
      JSON.stringify({
        success: true,
        message: `Processed ${processedTransactions.length} recurring transactions`,
        processed: processedTransactions,
      }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
        status: 200,
      }
    );
  } catch (error) {
    console.error(`Error processing recurring transactions: ${error.message}`);
    
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
      }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
        status: 500,
      }
    );
  }
});
