
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Create a Supabase client
const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const supabase = createClient(supabaseUrl, supabaseServiceKey);

interface ExchangeRateResponse {
  base: string;
  rates: Record<string, number>;
}

// Function to fetch exchange rates from a free API
async function fetchExchangeRates(): Promise<ExchangeRateResponse | null> {
  try {
    const response = await fetch("https://open.er-api.com/v6/latest/USD");
    
    if (!response.ok) {
      console.error("Exchange rate API error:", response.statusText);
      return null;
    }
    
    return await response.json();
  } catch (error) {
    console.error("Failed to fetch exchange rates:", error);
    return null;
  }
}

// Handle the request
serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders,
      status: 204,
    });
  }

  try {
    // Fetch the latest exchange rates
    const ratesData = await fetchExchangeRates();
    
    if (!ratesData) {
      return new Response(
        JSON.stringify({ error: "Failed to fetch exchange rates" }),
        {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 500,
        }
      );
    }

    // Store in the database for caching
    const { error } = await supabase
      .from('exchange_rates')
      .upsert(
        {
          id: 1, // Use a single row for rates
          rates: ratesData.rates,
          last_updated: new Date().toISOString(),
        },
        { onConflict: 'id' }
      );

    if (error) {
      console.error("Failed to store exchange rates:", error);
      return new Response(
        JSON.stringify({ error: "Failed to store exchange rates" }),
        {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 500,
        }
      );
    }

    return new Response(
      JSON.stringify({ success: true, rates: ratesData.rates }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      }
    );
  } catch (error) {
    console.error("Error processing request:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500,
      }
    );
  }
});
