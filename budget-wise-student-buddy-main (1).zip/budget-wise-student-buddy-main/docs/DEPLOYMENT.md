
# Deploying Your Budget App to Vercel

This guide will walk you through deploying your BudgetWise app to Vercel, a platform that's perfect for React applications.

## Prerequisites

1. A GitHub account
2. A Vercel account (you can sign up for free at https://vercel.com using your GitHub account)
3. Your project pushed to a GitHub repository

## Step 1: Push Your Project to GitHub

If you haven't already, you'll need to push your code to GitHub:

```bash
# Initialize a git repository if you haven't already
git init

# Add all files to git
git add .

# Commit your changes
git commit -m "Initial commit"

# Add your GitHub repository as a remote
git remote add origin https://github.com/yourusername/budget-wise.git

# Push your code to GitHub
git push -u origin main
```

## Step 2: Connect Vercel to Your GitHub Repository

1. Sign in to [Vercel](https://vercel.com)
2. Click on "Add New" > "Project"
3. Connect to your GitHub account if prompted
4. Select the repository with your BudgetWise app
5. Click "Import"

## Step 3: Configure the Project

In the configuration screen:

1. Framework Preset: Select "Vite"
2. Build and Output Settings: You can typically leave these as default
3. Environment Variables: This is crucial - you need to add your Supabase environment variables:

Add the following environment variables:

```
VITE_SUPABASE_URL=https://pfafcnfdgzmqwqvwmdpu.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBmYWZjbmZkZ3ptcXdxdndtZHB1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDQyMDc1ODUsImV4cCI6MjA1OTc4MzU4NX0.a0Xrx20MmsH14WfI399QfE3zCaoxuK61Xrg5pKCZyeI
```

4. Click "Deploy"

## Step 4: Wait for the Deployment

Vercel will now build and deploy your application. This usually takes a few minutes. You can watch the build logs to see the progress.

## Step 5: Configure Supabase for Production

For production use, you should configure Supabase to:

1. Set up proper authentication settings
2. Configure allowed domains in Supabase Auth settings
3. Check your security settings to ensure data is properly protected

In Supabase:

1. Go to your project dashboard
2. Navigate to Authentication > URL Configuration
3. Add your Vercel deployment URL (e.g., https://budget-wise.vercel.app) to:
   - Site URL
   - Redirect URLs
   - Allowed domains

## Step 6: Test Your Deployed Application

Once the deployment is complete, Vercel will provide you with a URL for your application (e.g., https://budget-wise.vercel.app).

Visit the URL and test all the features of your application to ensure everything is working as expected:

- User authentication
- Creating and managing budgets
- Recording transactions
- Export functionality
- Dark mode toggle

## Step 7: Set Up Custom Domain (Optional)

If you have a custom domain, you can connect it to your Vercel deployment:

1. Go to your project on Vercel
2. Navigate to "Settings" > "Domains"
3. Add your custom domain and follow the instructions to set up DNS records

## Step 8: Set Up Continuous Deployment

Vercel automatically sets up continuous deployment. Whenever you push changes to your main branch, Vercel will automatically rebuild and redeploy your application.

To make changes to your live site:

1. Make changes locally and test them
2. Commit your changes to git
3. Push to GitHub
4. Vercel will automatically detect the changes and redeploy

## Troubleshooting

If you encounter issues with your deployment:

1. Check the Vercel build logs for errors
2. Ensure all environment variables are correctly set
3. Verify that your Supabase project is correctly configured
4. Test authentication flows with the deployed URL

## Additional Resources

- [Vercel Documentation](https://vercel.com/docs)
- [Supabase Documentation](https://supabase.com/docs)
- [Vite Deployment Guide](https://vitejs.dev/guide/static-deploy.html)
